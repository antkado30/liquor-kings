/**
 * CartDrawer — two-step Validate → Submit UX (Phase 1 Week 1 of V1 roadmap,
 * 2026-05-30).
 *
 * Mirrors MLCC's actual user flow:
 *   1. User reviews cart (with instant rule-engine feedback per line)
 *   2. Clicks "Validate against MLCC" → backend RPA runs Stages 1-4 → we
 *      surface MILO's live cart state (in-stock items, out-of-stock items,
 *      totals, ADA breakdown, validate messages)
 *   3. User can edit cart (any mutation invalidates the validate result
 *      and the Submit button locks again — they must re-validate)
 *   4. User clicks "Submit Order" → confirmation modal → RPA runs Stages
 *      1-5 → real checkout
 *
 * Two layers of validation, each serving a different purpose:
 *   - Instant rule-engine validation (validateCart from api/cart) — runs
 *     locally as the cart changes, surfaces split-case errors, 9L
 *     minimum-per-ADA, etc. WITHOUT hitting MILO. Catches obvious issues
 *     in 50ms. ALWAYS runs.
 *   - MLCC live validation (validate_only RPA run) — actually logs into
 *     MILO, adds items, runs MILO's real Validate. Sees real stock
 *     status, surfaces OOS items, MILO's own validation messages. Costs
 *     30-60s + a few pennies per run.
 *
 * Submit is GATED on (a) instant rule-engine clean AND (b) at least one
 * successful MLCC validate. This means a user can never accidentally
 * submit a cart that hasn't been confirmed against MLCC's live view.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { validateCart, type CartValidationResult } from "../api/cart";
import {
  getRunSummary,
  isTerminalStatus,
  recoverStore,
  triggerMlccCartReset,
  type RecoverStoreResult,
  type RunMode,
} from "../api/execution";
import {
  createOrderTemplate,
  listOrderTemplates,
  loadOrderTemplate,
  type OrderTemplate,
} from "../api/orderTemplates";
import { cartLineId, type CartContextValue } from "../hooks/useCart";
import { useSubmission } from "../hooks/useSubmission";
import { useActiveOrder } from "../hooks/useActiveOrder";
import { useLockBodyScroll } from "../hooks/useLockBodyScroll";
import type { BackgroundPreValidate } from "../hooks/useBackgroundPreValidate";
import { hashCart } from "../hooks/useBackgroundPreValidate";
import { oosDisplayLabel } from "../lib/oos-display";
import { resolvePlaceGate } from "../lib/place-gate";
import { resolveDisplayedTotal } from "../lib/cart-total";
import { useHideTabBar } from "../hooks/useHideTabBar";
import { SubmitConfirmationModal } from "./SubmitConfirmationModal";
import {
  IconAlert,
  IconCalendar,
  IconCheck,
  IconClipboardList,
  IconFileText,
  IconBookmark,
  IconTrash,
  IconX,
} from "./Icons";
import {
  generateValidQuantities,
  getOrderingRuleDisplay,
} from "../lib/mlcc-ordering-rules";
import { humanizeRunFailure } from "../lib/run-failure-human";
import {
  RPA_STAGES_SUBMIT,
  RPA_STAGES_VALIDATE,
  RpaProgressPanel,
  STUCK_RETRY_THRESHOLD_SEC,
} from "./RpaProgress";
import { nonGlassContainerSuffix, packCountSuffix } from "../lib/container-label";
import { REAL_SUBMISSION_WIRED } from "../config/submission";

function money(n: number): string {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(n);
}

/**
 * Compute "inferred OOS" — cart items the user added that did NOT show up
 * in MILO's ada_breakdown active items. Almost always means MILO demoted
 * them to its OOS section even though Stage 3 thought it added them.
 *
 * Used in two places:
 *   1. ValidateResultPanel — renders the list of likely-OOS items.
 *   2. CartDrawer parent — gates Submit on inferredOos.length === 0
 *      (otherwise we'd surface "MLCC says ready for checkout" + a list
 *      of OOS items in the same banner, which is incoherent).
 *
 * NOTE 2026-06-04 (#53 ships): the server now emits structured
 * `out_of_stock_items` with `reason: "oos_section" | "validate_demoted"`
 * directly. Use `getServerOosCodes` for the new authoritative source.
 * This function is retained as a *consistency check* — if the server
 * misses a demotion (parser regression, MILO UI change), the client
 * falls back to inferred and logs a divergence warning in dev.
 */
function computeInferredOos(
  cartItems: CartContextValue["items"],
  result: import("../api/execution").ValidateResult | null,
): CartContextValue["items"] {
  if (!result) return [];
  const adaBreakdown = Array.isArray(result.ada_breakdown) ? result.ada_breakdown : [];
  const adaActiveCodes = new Set<string>();
  for (const ada of adaBreakdown) {
    const items = Array.isArray((ada as { items?: unknown[] }).items)
      ? ((ada as { items: unknown[] }).items as unknown[])
      : [];
    for (const it of items) {
      const code = (it as { code?: unknown })?.code;
      if (typeof code === "string" && code) adaActiveCodes.add(code);
    }
  }
  /*
    Exclude items already in items_rejected (2026-06-01 fix for #61).
    Tony's Tito's 750ml false-OOS flake: Stage 3 timed out waiting for
    MILO's quick-add list to render → reported the item in
    items_rejected ("did not appear in quick add list"). Without this
    filter, the item ALSO appeared in inferredOos with the misleading
    "out of stock" label. Real cause is a Stage 3 timeout, not stock.
    The rejected list now owns the user-facing message for those rows.
  */
  const rejectedCodes = new Set<string>();
  const rejectedList = Array.isArray(result.items_rejected)
    ? result.items_rejected
    : [];
  for (const it of rejectedList) {
    const code = (it as { code?: unknown })?.code;
    if (typeof code === "string" && code) rejectedCodes.add(code);
  }
  return cartItems.filter(
    (line) =>
      !adaActiveCodes.has(line.product.code) &&
      !rejectedCodes.has(line.product.code),
  );
}

/**
 * Cart items the SERVER tagged as OOS via Stage 4's structured
 * out_of_stock_items list (task #53, 2026-06-04). Includes both:
 *   - oos_section: MILO put it in its dedicated OOS table
 *   - validate_demoted: Stage 3 saw it in cart, Stage 4 lost track
 *     after the validate click
 * Server-authoritative — the inferredOos computation is now a backstop
 * for the case where the server parser regresses.
 */
function getServerOosCodes(
  result: import("../api/execution").ValidateResult | null,
): Set<string> {
  if (!result) return new Set();
  const list = Array.isArray(result.out_of_stock_items)
    ? result.out_of_stock_items
    : [];
  const codes = new Set<string>();
  for (const it of list) {
    const code = (it as { code?: unknown })?.code;
    if (typeof code === "string" && code) codes.add(code);
  }
  return codes;
}

/*
  Recognize Stage 3 timeout rejections so the UI shows a recoverable
  "try re-validate" message instead of the hard "MLCC rejected this"
  language we use for genuine rule violations. The reason string is
  produced by add-items-to-cart.js (services/api/src/rpa/stages/) and
  is stable enough to pattern-match.
*/
function isStage3TimeoutRejection(reason: unknown): boolean {
  if (typeof reason !== "string") return false;
  return /quick add list|did not appear/i.test(reason);
}

/*
 * Stage lists + the rich progress panel moved to ./RpaProgress
 * (2026-07-27) so the status pill's LIVE sheet renders the identical
 * panel — one truth for what a running MILO job looks like.
 */

type CartDrawerProps = {
  cart: CartContextValue;
  onClose: () => void;
  onSubmit?: () => void;
  /**
   * Optional callback fired when the user taps a cart line's product
   * name (task #51, 2026-05-30 — Amazon-style sibling browsing). The
   * scanner page handles opening the ProductCard for that bottle's
   * family so the user can swap sizes / see other SKUs in the same
   * brand without re-scanning. If omitted, the line title is not
   * tappable and the drawer behaves the same as before.
   */
  onLineProductClick?: (product: import("../types").MlccProduct) => void;
  /**
   * Background pre-validate cache (task #47, 2026-06-02). When the
   * user taps Validate, useSubmission checks this cache first; on a
   * hit, the state machine skips straight to validateDone instead of
   * running the full sync+trigger+poll pipeline. Optional — without
   * it, the drawer falls back to the foreground-only flow.
   */
  preValidate?: BackgroundPreValidate;
  /**
   * Store identity for the pre-submit verification modal (task #89,
   * 2026-06-07). Optional — when missing, the modal still renders
   * with a generic "Your store" header. Source: /home/smart-cards
   * store_meta.store_name / liquor_license, surfaced via ScannerPage.
   */
  storeName?: string | null;
  storeLicense?: string | null;
  /**
   * AUDIT #15b (2026-06-13): is this store armed for real MLCC orders right
   * now (global LK_ALLOW_ORDER_SUBMISSION=yes AND this store's
   * allow_order_submission=true)? When false, the pre-submit modal tells the
   * user up front that Submit will run as a preview/dry-run only — Tony's
   * call to be fully transparent about this before the ~2-minute RPA run,
   * not just after. Defaults to false (safe/preview) when omitted.
   */
  allowOrderSubmission?: boolean;
  /**
   * THE CART TAB FIX (Tony, 2026-07-26: "when I press on the cart logo on
   * the bottom middle i want it to be an actual cart page not half cart
   * with a background of the scanner"). "drawer" (default) is the classic
   * bottom sheet the scanner's top-right cart icon opens — quick peek,
   * tab bar hidden, body locked. "page" renders the SAME component as a
   * real full page inside the /cart route: no backdrop, no grab handle,
   * no close X, tab bar stays visible, the page scrolls normally, and
   * the sticky Check/Place footer sits ABOVE the tab bar. Zero changes
   * to the money state machine — this prop only swaps the chrome.
   */
  layout?: "drawer" | "page";
};

export function CartDrawer({
  cart,
  onClose,
  onLineProductClick,
  preValidate,
  storeName,
  storeLicense,
  allowOrderSubmission = false,
  layout = "drawer",
}: CartDrawerProps) {
  const isPage = layout === "page";
  /*
   * Hide the bottom tab bar while the DRAWER is open. Tony's
   * 2026-06-07 critical bug: the tab bar was covering the Submit
   * button at the bottom of the drawer so the user literally could
   * not reach it. This kills the overlap. In PAGE mode the tab bar
   * must stay (it's how you leave the page) — the footer clears it
   * via CSS instead.
   */
  useHideTabBar(!isPage);
  useLockBodyScroll(!isPage);
  const navigate = useNavigate();
  const {
    items,
    groupedByAda,
    totalCost,
    clearCart,
    savedItems,
    saveForLater,
    moveSavedToCart,
    removeSaved,
    incrementQuantity,
    decrementQuantity,
    removeItem,
    updateQuantity,
  } = cart;
  // Wire pre-validate cache into useSubmission so startValidate can
  // short-circuit on a fresh cached result (task #47, 2026-06-02).
  const submission = useSubmission(preValidate);
  const { state, startValidate, startSubmit, invalidateValidation, reset, cancelActiveRun, fireOrder } = submission;
  // App-level active-order tracker (P1a). The new "Place Order" flow hands the
  // fired runId here so the persistent OrderStatusPill shows progress after the
  // drawer closes. activeOrder also gates double-fire (one order in flight).
  const { activeOrder, trackOrder, lastGreenCheck } = useActiveOrder();

  // Compound "is the flow doing something async right now" flag. Used to
  // disable UI controls during sync / poll. Covers both validate and
  // submit phases.
  const isBusy =
    state.kind === "validateSyncing" ||
    state.kind === "validateStarting" ||
    state.kind === "validatePolling" ||
    state.kind === "submitStarting" ||
    state.kind === "submitPolling";

  // Inferred OOS for the current validate result. Empty when not in
  // validateDone state, or when MILO showed all cart items as active.
  // Used to gate Submit so we never offer "submit a cart that has
  // likely-OOS items in it".
  //
  // 2026-06-04 #53: server now emits structured out_of_stock_items
  // covering both oos_section and validate_demoted cases. Treat that as
  // authoritative. We still compute inferredOos as a backstop — if the
  // server misses an item (parser regression / MILO UI change), we
  // catch it client-side and warn in dev so the divergence is visible.
  const serverOosCodes =
    state.kind === "validateDone"
      ? getServerOosCodes(state.validateResult)
      : new Set<string>();
  const inferredOos =
    state.kind === "validateDone"
      ? computeInferredOos(items, state.validateResult)
      : [];

  // Has MLCC actually said this cart is OK? Only true when the last
  // validate ended succeeded AND MILO said canCheckout=true AND
  // there are no server-tagged OOS items AND no client-inferred OOS
  // items (the inferred check is a backstop against a server parser
  // regression — see getServerOosCodes comment above).
  const mlccValidatePassed =
    state.kind === "validateDone" &&
    state.finalStatus === "succeeded" &&
    state.validateResult?.can_checkout === true &&
    serverOosCodes.size === 0 &&
    inferredOos.length === 0;

  // Dev-only divergence warning: if the server says "no OOS" but the
  // client-side inferred-from-absence check finds some, that's a sign
  // the Stage 4 parser missed a demotion. Surfaces in browser console
  // so we catch parser regressions in real-world use.
  useEffect(() => {
    if (import.meta.env.DEV && state.kind === "validateDone") {
      if (serverOosCodes.size === 0 && inferredOos.length > 0) {
        console.warn(
          "[#53] Server reported no OOS but client inferred",
          inferredOos.length,
          "demoted items:",
          inferredOos.map((line) => line.product.code),
        );
      }
    }
  }, [state.kind, serverOosCodes.size, inferredOos.length]);

  const [isCheckingValidation, setIsCheckingValidation] = useState(false);
  const [validationResult, setValidationResult] = useState<CartValidationResult | null>(null);
  const validationRequestRef = useRef(0);

  /**
   * Confirmation gate before triggering the real RPA submit. Stage 5 is
   * triple-gated server-side, this is the UX-level "are you sure?"
   */
  const [confirmSubmit, setConfirmSubmit] = useState(false);

  // Non-blocking "Place Order" fire path (P1b). isFiring covers the brief
  // sync+trigger window before we hand off to the tracker; fireError surfaces
  // a trigger failure inline (the run never started, so no pill to show).
  const [isFiring, setIsFiring] = useState(false);
  const [fireError, setFireError] = useState<string | null>(null);

  /*
   * "Start over" escape hatch (2026-06-26). When a validate poll blows past
   * STUCK_RETRY_THRESHOLD_SEC with no result, we surface a "Taking too long?
   * Start over" control. Tapping it calls the existing recoverStore() (a
   * stale-only, submit-guarded recovery endpoint — never the raw fetch) and
   * branches honestly on the real response. It must NEVER claim a clear it
   * didn't get, and must NEVER invite a re-submit when a run may have reached
   * checkout (the submit_stage case).
   *
   * We need the poll's elapsed time here in the parent (the live clock lives
   * in the PollingElapsedStatus child), so a 1s ticker runs only while we're
   * in validatePolling and drives both the button-visibility gate and the
   * existing slow-MILO message indirectly via the child's own clock.
   */
  const [nowTick, setNowTick] = useState(() => Date.now());
  useEffect(() => {
    if (state.kind !== "validatePolling") return;
    setNowTick(Date.now());
    const id = window.setInterval(() => setNowTick(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, [state.kind]);

  const validateElapsedSec =
    state.kind === "validatePolling"
      ? Math.max(0, Math.floor((nowTick - state.startedAtMs) / 1000))
      : 0;

  const showStartOver =
    state.kind === "validatePolling" &&
    validateElapsedSec >= STUCK_RETRY_THRESHOLD_SEC;

  const [recoverState, setRecoverState] = useState<
    | { kind: "idle" }
    | { kind: "working" }
    | { kind: "notice"; tone: "ok" | "warn" | "err"; text: string }
  >({ kind: "idle" });

  // Synchronous in-flight guard for the Start over button. The disabled prop
  // (driven by recoverState) only takes effect after a re-render, so without
  // this ref a rapid double-tap would fire recoverStore() twice before the
  // button disabled. The ref makes the second tap a true no-op.
  const recoverInFlightRef = useRef(false);

  // Live mirror of the submission state so the async recover handler can tell
  // whether the poll is still in flight when recoverStore() resolves (it may
  // have finished naturally while we waited, or the user may have backgrounded
  // the app and returned). We only force a reset-to-idle when a poll is
  // actually still running — never clobber a real validateDone that landed in
  // the meantime.
  const stateRef = useRef(state);
  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  // Once we've definitively moved on to a new validate (syncing/starting/done/
  // error), drop any leftover recover notice. The warn notices for the
  // submit_stage / still-alive branches stay visible during validatePolling,
  // and the "tap Validate to try again" ok notices stay visible in idle.
  useEffect(() => {
    if (state.kind !== "idle" && state.kind !== "validatePolling") {
      setRecoverState({ kind: "idle" });
    }
  }, [state.kind]);

  const handleStartOver = async () => {
    if (recoverInFlightRef.current) return; // rapid double-tap → no-op
    recoverInFlightRef.current = true;
    setRecoverState({ kind: "working" });

    let res: RecoverStoreResult;
    try {
      // recoverStore() already normalizes network/timeout failures into
      // { ok: false, error }, but defend against an unexpected throw so the
      // button can never get stuck disabled.
      res = await recoverStore();
    } catch (e) {
      res = { ok: false, error: e instanceof Error ? e.message : String(e) };
    } finally {
      recoverInFlightRef.current = false;
    }

    const recovered = res.recovered ?? [];
    const stillLive = res.stillLive ?? [];
    // Only tear down the poll if one is genuinely still running. If the run
    // reached a terminal state while we were recovering, leave that result
    // intact — don't clobber a real validateDone with an idle reset.
    const stillPolling = stateRef.current.kind === "validatePolling";

    if (!res.ok) {
      setRecoverState({
        kind: "notice",
        tone: "err",
        text: res.error
          ? `Couldn't reach recovery: ${res.error}. Tap to try again.`
          : "Couldn't reach recovery. Tap to try again.",
      });
      return;
    }

    // Cleared a confirmed-dead run → safe to cancel the poll and let the
    // user re-validate.
    if (recovered.length > 0) {
      if (stillPolling) cancelActiveRun();
      setRecoverState({
        kind: "notice",
        tone: "ok",
        text: "Cleared a stuck run — tap Validate to try again.",
      });
      return;
    }

    // recovered.length === 0. Branch on WHY the server held onto the run.
    const hasSubmitStage = stillLive.some((r) => r.reason === "submit_stage");
    if (hasSubmitStage) {
      // The run reached at/after checkout — an order may genuinely be
      // finishing on MLCC right now. DO NOT reset into a state that invites a
      // new submit; keep the poll as-is and tell the user to check Orders.
      setRecoverState({
        kind: "notice",
        tone: "warn",
        text: "Your order may still be finishing on MLCC. Don't re-submit — check Orders first.",
      });
      return;
    }

    const hasRecentHeartbeat = stillLive.some(
      (r) => r.reason === "recent_heartbeat",
    );
    if (hasRecentHeartbeat) {
      // The run is still actively heartbeating — it's not stuck, just slow.
      // Don't force a reset; we don't want two live runs on one store.
      setRecoverState({
        kind: "notice",
        tone: "warn",
        text: "It's still working — give it a moment.",
      });
      return;
    }

    // ok && nothing recovered && nothing still live → the store was already
    // free (e.g. the run died and was reaped between our poll stalling and
    // the recover call). Cancel the wedged client-side poll and let them retry.
    if (stillPolling) cancelActiveRun();
    setRecoverState({
      kind: "notice",
      tone: "ok",
      text: "Nothing stuck — tap Validate to try again.",
    });
  };

  // ─── Instant rule-engine validation (unchanged from prior CartDrawer) ──
  //
  // Debounced 400ms after the cart changes. Surfaces split-case / quantity
  // errors per line and ADA 9L violations. Does NOT hit MILO.
  useEffect(() => {
    if (items.length === 0) {
      setIsCheckingValidation(false);
      setValidationResult(null);
      return;
    }
    const requestId = validationRequestRef.current + 1;
    validationRequestRef.current = requestId;
    const timer = window.setTimeout(() => {
      setIsCheckingValidation(true);
      void validateCart(items.map((line) => ({ code: line.product.code, quantity: line.quantity })))
        .then((result) => {
          if (validationRequestRef.current !== requestId) return;
          setValidationResult(result);
          setIsCheckingValidation(false);
        })
        .catch((error: unknown) => {
          if (validationRequestRef.current !== requestId) return;
          setValidationResult({
            ok: false,
            error: error instanceof Error ? error.message : String(error),
          });
          setIsCheckingValidation(false);
        });
    }, 400);
    return () => {
      window.clearTimeout(timer);
    };
  }, [items]);

  // ─── Cart-mutation handlers that ALSO invalidate validate state ───────
  //
  // Whenever the user touches the cart, our validateDone state becomes
  // stale — the next submit MUST re-validate. invalidateValidation()
  // resets the submission state to idle so the Submit button locks again.
  const handleIncrement = (lineId: string) => {
    if (state.kind === "validateDone") invalidateValidation();
    incrementQuantity(lineId);
  };
  const handleDecrement = (lineId: string) => {
    if (state.kind === "validateDone") invalidateValidation();
    decrementQuantity(lineId);
  };
  const handleRemove = (code: string) => {
    if (state.kind === "validateDone") invalidateValidation();
    removeItem(code);
  };
  const handleUpdateQuantity = (code: string, qty: number) => {
    if (state.kind === "validateDone") invalidateValidation();
    updateQuantity(code, qty);
  };
  // handleClearCart used to be a separate "Clear scanner cart" button;
  // Tony's 2026-06-07 redesign combined it into "Clear cart" which
  // goes through the MLCC reset flow (which calls clearCart() locally
  // on success too). Kept here for reference / future use.
  void clearCart; // mark referenced
  void reset; // mark referenced
  // P1b (2026-06-26): the primary flow is now the non-blocking "Place Order"
  // fire path. The two-step validate→submit state machine (startValidate /
  // startSubmit + their disabled gates) is intentionally left in place but
  // UNREACHED from the new flow — cleanup is a later portion. Mark startSubmit
  // referenced so noUnusedLocals stays happy until then. (validateDisabled /
  // submitDisabled are void-marked at their definition site below.)
  void startSubmit;

  /*
   * "Reset MLCC cart" handler (task #57, 2026-06-04). Fires the
   * cart_reset_only execution run that logs into MILO and clicks Clear
   * Cart server-side. Polls until terminal. Resolves the lie where
   * the local "Clear scanner cart" left MILO holding items.
   *
   * On success we ALSO clear the local cart, since after MILO is empty
   * there's no reason to keep local lines around.
   */
  const [mlccResetState, setMlccResetState] = useState<
    | { kind: "idle" }
    | { kind: "confirm" }
    | { kind: "running"; runId: string }
    | { kind: "done"; cleared: boolean; itemCount: number }
    | { kind: "error"; message: string }
  >({ kind: "idle" });

  const handleMlccReset = async () => {
    setMlccResetState({ kind: "confirm" });
  };

  /*
   * Order template state (task #72, 2026-06-04 afternoon).
   *
   * Dad rebuilds his Thursday MLCC order from scratch every week even
   * though 80% of it is the same staples. Templates let him save the
   * weekly base order once and load it back as a starting point.
   *
   * UI states:
   *   templatesState.kind === "idle"       → buttons visible if user has any
   *   templatesState.kind === "loading"    → fetching list
   *   templatesState.kind === "loaded"     → list ready
   *   templatesState.kind === "saving"     → save modal open
   *   templatesState.kind === "loadingOne" → loading a specific template
   */
  const [templates, setTemplates] = useState<OrderTemplate[]>([]);
  const [templatesLoaded, setTemplatesLoaded] = useState(false);
  const [showSaveTemplate, setShowSaveTemplate] = useState(false);
  const [saveTemplateName, setSaveTemplateName] = useState("");
  /*
   * Scheduling state (task #75). null = no schedule (manual loads only).
   * 0-6 = day-of-week. Default is "no schedule" so users opt in.
   */
  const [saveTemplateDow, setSaveTemplateDow] = useState<number | null>(null);
  const [saveTemplateBusy, setSaveTemplateBusy] = useState(false);
  const [templateError, setTemplateError] = useState<string | null>(null);
  const [templateLoading, setTemplateLoading] = useState<string | null>(null);
  const [templateLoadResult, setTemplateLoadResult] = useState<{
    name: string;
    addedCount: number;
    missingCount: number;
  } | null>(null);
  const [showTemplatePicker, setShowTemplatePicker] = useState(false);

  // One-shot template fetch when the drawer opens.
  useEffect(() => {
    if (templatesLoaded) return;
    let cancelled = false;
    void listOrderTemplates().then((r) => {
      if (cancelled) return;
      if (r.ok) setTemplates(r.data);
      setTemplatesLoaded(true);
    });
    return () => {
      cancelled = true;
    };
  }, [templatesLoaded]);

  const handleSaveTemplate = async () => {
    const name = saveTemplateName.trim();
    if (!name || items.length === 0) return;
    setSaveTemplateBusy(true);
    setTemplateError(null);
    const itemsPayload = items.map((line) => ({
      mlcc_code: line.product.code,
      quantity: line.quantity,
      name: line.product.name,
      bottle_size_ml: line.product.bottle_size_ml ?? undefined,
    }));
    const r = await createOrderTemplate({
      name,
      items: itemsPayload,
      schedule_dow: saveTemplateDow,
    });
    setSaveTemplateBusy(false);
    if (!r.ok) {
      setTemplateError(r.error);
      return;
    }
    setTemplates((cur) => [r.data, ...cur]);
    setShowSaveTemplate(false);
    setSaveTemplateName("");
    setSaveTemplateDow(null);
  };

  const handleLoadTemplate = async (templateId: string) => {
    setTemplateLoading(templateId);
    setTemplateError(null);
    const r = await loadOrderTemplate(templateId);
    setTemplateLoading(null);
    setShowTemplatePicker(false);
    if (!r.ok) {
      setTemplateError(r.error);
      return;
    }
    // Push each hydrated item into the cart. addItem merges duplicates,
    // so loading a template on top of an existing cart adds-quantity
    // instead of duplicating lines.
    for (const it of r.data.items) {
      cart.addItem(it.product, it.quantity);
    }
    setTemplateLoadResult({
      name: r.data.template.name,
      addedCount: r.data.items.length,
      missingCount: r.data.missingCodes.length,
    });
    // Auto-dismiss the success badge after 3s.
    setTimeout(() => {
      setTemplateLoadResult((cur) => (cur ? null : cur));
    }, 3000);
  };

  /*
   * Instant-feel version (task #71, 2026-06-04 afternoon).
   *
   * Old flow blocked the UI for 30-60s while the RPA cleared MILO. Tony
   * called it out — "should take an instant." MILO's site genuinely IS
   * slow, but the local cart can clear in 1ms. So:
   *   - Tap → confirm → IMMEDIATELY clear local cart + show "MLCC
   *     syncing" badge → user can keep working
   *   - RPA fires in background, polls silently
   *   - On success: badge auto-dismisses after 2s
   *   - On error: badge turns red with the message and stays until
   *     user dismisses (we still want them to know if it failed)
   *
   * The `running` state intentionally no longer disables the rest of
   * the UI — only the Reset button itself is disabled while a sync is
   * in flight, to prevent double-firing.
   */
  const confirmMlccReset = async () => {
    // Step 1: clear local IMMEDIATELY. User sees empty cart in <100ms.
    if (state.kind !== "idle") reset();
    clearCart();
    setMlccResetState({ kind: "running", runId: "" });

    // Step 2: kick off the RPA run.
    const trigger = await triggerMlccCartReset();
    if (!trigger.ok) {
      setMlccResetState({ kind: "error", message: trigger.error });
      return;
    }
    setMlccResetState({ kind: "running", runId: trigger.runId });

    // Step 3: poll quietly in the background. User can ignore us.
    //
    // P0 (2026-06-14, Sweep 2): 16 minutes is a true upper bound — the
    // execution_runs reaper (STALE_RUN_MINUTES=15) guarantees every run
    // reaches a terminal state by then. The old 3-minute cutoff told the
    // user "tap Reset to retry" while the original cart-reset run was
    // often still legitimately in flight; retrying just queued a second
    // reset behind the first (busyStores) for no benefit. Back off to
    // 10s polls after the first minute.
    const start = Date.now();
    const POLL_BACKOFF_AFTER_MS = 60_000;
    const POLL_BACKOFF_INTERVAL_MS = 10_000;
    const MAX_POLL_MS = 16 * 60 * 1000;
    let pollInterval = 2000;
    while (Date.now() - start < MAX_POLL_MS) {
      await new Promise((r) => setTimeout(r, pollInterval));
      if (Date.now() - start > POLL_BACKOFF_AFTER_MS) {
        pollInterval = POLL_BACKOFF_INTERVAL_MS;
      }
      const summary = await getRunSummary({ runId: trigger.runId });
      if (!summary.ok) continue;
      if (isTerminalStatus(summary.summary.status)) {
        if (summary.summary.status === "succeeded") {
          const evidence = (summary.summary as unknown as {
            evidence?: Array<{
              kind?: string;
              attributes?: { cleared?: boolean; itemCountBefore?: number };
            }>;
          }).evidence;
          const summaryEntry = (evidence ?? []).find(
            (e) => e?.kind === "cart_reset_summary",
          );
          const cleared = !!summaryEntry?.attributes?.cleared;
          const itemCount = summaryEntry?.attributes?.itemCountBefore ?? 0;
          setMlccResetState({ kind: "done", cleared, itemCount });
          // Auto-dismiss the success badge after 2s so it doesn't clutter.
          setTimeout(() => {
            setMlccResetState((cur) =>
              cur.kind === "done" ? { kind: "idle" } : cur,
            );
          }, 2000);
        } else {
          // Errors stick around until the user dismisses (they're real).
          setMlccResetState({
            kind: "error",
            message: `MLCC sync failed (status: ${summary.summary.status}). MILO may still have items — tap Reset to retry.`,
          });
        }
        return;
      }
    }
    setMlccResetState({
      kind: "error",
      message:
        "MLCC sync is taking unusually long but is still running in the background. Check Orders in a few minutes before retrying.",
    });
  };

  const hasDefinitiveValidationFailure =
    validationResult?.ok === true && validationResult.valid === false;
  // Validate is allowed only when rule-engine validation has cleared. We
  // don't want to waste an RPA run on a cart that obviously won't pass.
  const validateDisabled =
    isBusy || items.length === 0 || hasDefinitiveValidationFailure;
  // Submit is allowed only AFTER a successful MLCC validate, AND the
  // rule-engine is still clean (user hasn't edited the cart since).
  const submitDisabled = isBusy || !mlccValidatePassed || hasDefinitiveValidationFailure;
  // P1b: validateDisabled / submitDisabled gated the now-unreached two-step
  // buttons. Kept (not deleted) but marked referenced here.
  void validateDisabled;
  void submitDisabled;

  // ─── Non-blocking "Place Order" flow (P1b, 2026-06-26) ────────────────
  // The primary CTA is now ONE button that fires the full background pipeline
  // after the confirmation modal and hands the runId to the app-level tracker.
  // Pre-gate is the INSTANT LOCAL rules check (rulesValid), NOT a MILO
  // round-trip. An order already in flight (tracker has a non-terminal
  // activeOrder) disables the button to prevent double-fire.
  // Narrowed through validationResult?.ok === true (CartValidationResult is a
  // discriminated union; .valid only exists on the ok:true branch).
  const rulesValid = validationResult?.ok === true && validationResult.valid === true;
  const orderInFlight = activeOrder !== null && activeOrder.result === null;
  const canPlaceOrder =
    !isFiring &&
    !orderInFlight &&
    items.length > 0 &&
    !isCheckingValidation &&
    rulesValid;

  // Single source of truth for "is a REAL submission wired+armed" (P1c). The
  // store flag is only one of three gates; the app can't actually submit
  // until REAL_SUBMISSION_WIRED flips true (P2). Until then every "order" is
  // a dry-run practice check, and the button/modal copy must say so — never
  // imply a real order. Fed to SubmitConfirmationModal in place of the raw
  // store flag (whose not-armed copy is already correct).
  const submissionArmed = allowOrderSubmission && REAL_SUBMISSION_WIRED;

  // ─── Two-step Check → SEE → Place (2026-07-11, Tony's 2026-07-01 design) ──
  // Armed shows TWO explicit buttons, MILO's rhythm: "Check with MLCC"
  // (always available, direct fire — a check is non-destructive, so no
  // confirm modal) and "Place Order" (keeps the line-by-line confirm modal;
  // doctrine #3 pre-commit verification is for destructive actions).
  // Place unlocks ONLY while the last GREEN check is fresh (<10 min) and
  // the cart is byte-identical to what MILO blessed — any edit re-locks it
  // via the hash mismatch, no event wiring needed. UX honesty only: the
  // server's Stage-5 triple gate re-validates regardless.
  const itemsHash = hashCart(items);
  // Minute-ticker so the 10-minute expiry re-locks the button on screen
  // without requiring a tap. Armed-only — practice mode has no Place.
  const [, setGateTick] = useState(0);
  useEffect(() => {
    if (!submissionArmed) return;
    const t = setInterval(() => setGateTick((n) => n + 1), 30_000);
    return () => clearInterval(t);
  }, [submissionArmed]);
  const placeGate = resolvePlaceGate({
    armed: submissionArmed,
    currentCartHash: itemsHash,
    lastGreenCheck,
    nowMs: Date.now(),
    rulesValid,
    busy: isFiring || orderInFlight,
  });

  /*
    TONY-WANTS 7/16 #3 — show MILO's real net once THIS cart is priced.
    Net comes from the succeeded validate's order_summary; it's only
    "current" when the last green check's cart hash matches what's on
    screen (any edit reverts to the client estimate — never a stale MLCC
    price). See lib/cart-total.ts for the honesty rules.
  */
  const miloNetTotal =
    state.kind === "validateDone" && state.finalStatus === "succeeded"
      ? (state.validateResult?.order_summary?.netTotal ?? null)
      : null;
  const cartMatchesGreenCheck =
    lastGreenCheck != null && lastGreenCheck.cartHash === itemsHash;
  const displayedTotal = resolveDisplayedTotal({
    clientTotal: totalCost,
    miloNetTotal,
    cartMatchesGreenCheck,
  });

  /*
    Shared fire path for BOTH buttons (and the confirm modal): sync the
    cart, trigger the run (validate_only latches onto an identical
    in-flight background check — the 2026-07-11 dedupe), hand the runId +
    the fired cart's hash to the app-level tracker, close the drawer. The
    hash is what lets a green check unlock Place for exactly these lines.
  */
  const fireRun = useCallback(
    (mode: RunMode) => {
      setFireError(null);
      setIsFiring(true);
      void (async () => {
        const r = await fireOrder(items, mode);
        setIsFiring(false);
        if (r.ok) {
          trackOrder(r.runId, mode, { cartHash: itemsHash });
          onClose();
        } else {
          setFireError(r.error);
        }
      })();
    },
    [fireOrder, items, itemsHash, trackOrder, onClose],
  );

  /*
    One-tap "Remove these N and check again" (TONY-WANTS 7/16 #0 — stated
    live mid-order: "we shouldn't have to fix the cart… at least give an
    option to remove all of those items to proceed"). A red check with OOS
    lines used to strand the operator hand-hunting codes out of a 34-line
    cart. This strips exactly what MILO rejected and fires a fresh check
    in one tap.

    Honesty preserved: this automates the CLEANUP, not the gate — the new
    check must still come back green before Place unlocks (hash mismatch
    re-locks the moment lines are removed, same as any edit).

    Race note: fireOrder takes the REMAINING list explicitly — never the
    `items` closure — because removeItem's setState hasn't landed inside
    this same tick.
  */
  const removeOosAndRecheck = useCallback(() => {
    if (state.kind !== "validateDone") return;
    const oosSet = new Set<string>(serverOosCodes);
    for (const line of inferredOos) oosSet.add(line.product.code);
    for (const it of state.validateResult?.out_of_stock_items ?? []) {
      const c = it?.code != null ? String(it.code).trim() : "";
      if (c !== "") oosSet.add(c);
    }
    if (oosSet.size === 0) return;

    const remaining = items.filter((line) => !oosSet.has(line.product.code));
    for (const code of oosSet) removeItem(code);

    if (remaining.length === 0) {
      // Whole cart was OOS — nothing left to check. Removal already done.
      setFireError(null);
      return;
    }

    setFireError(null);
    setIsFiring(true);
    void (async () => {
      const r = await fireOrder(remaining, "validate_only");
      setIsFiring(false);
      if (r.ok) {
        trackOrder(r.runId, "validate_only", { cartHash: hashCart(remaining) });
        onClose();
      } else {
        setFireError(r.error);
      }
    })();
  }, [state, serverOosCodes, inferredOos, items, removeItem, fireOrder, trackOrder, onClose]);

  // Every OOS code the current check surfaced (server list + inferred
  // backstop) — drives the pinned strip + the one-tap button label.
  const oosCodesForRecheck = useMemo(() => {
    if (state.kind !== "validateDone") return new Set<string>();
    const set = new Set<string>(serverOosCodes);
    for (const line of inferredOos) set.add(line.product.code);
    for (const it of state.validateResult?.out_of_stock_items ?? []) {
      const c = it?.code != null ? String(it.code).trim() : "";
      if (c !== "") set.add(c);
    }
    return set;
  }, [state, serverOosCodes, inferredOos]);

  // Cart-wide blockers shown above the validate button. Per-line errors
  // render inline on their cart line below.
  const validationBlockers = useMemo(() => {
    if (validationResult?.ok !== true || validationResult.valid !== false) return [];
    const cartCodes = new Set(items.map((line) => line.product.code));
    const blockers: string[] = validationResult.errors
      .filter((err) => {
        const codeStr = String(err.code);
        if (cartCodes.has(codeStr)) return false; // shown inline on the line
        if (codeStr.startsWith("ADA_")) return false; // adaBreakdown loop covers it
        return true;
      })
      .map((err) => err.reason)
      .filter((reason) => reason.trim().length > 0);
    for (const [adaNumber, info] of Object.entries(validationResult.adaBreakdown)) {
      if (info.meetsMinimum) continue;
      const matchedGroup = groupedByAda.find((group) => group.adaNumber === adaNumber);
      const adaName = matchedGroup?.adaName || `ADA ${adaNumber}`;
      const litersShort = Math.max(0, 9 - info.liters);
      blockers.push(`${adaName} is ${litersShort.toFixed(2)} L under the 9 L minimum.`);
    }
    return [...new Set(blockers)];
  }, [groupedByAda, validationResult, items]);

  const lineErrorFor = (code: string) =>
    validationResult?.ok === true
      ? validationResult.errors.find((err) => String(err.code) === code)
      : undefined;

  const handleClose = () => {
    if (isBusy) return;
    onClose();
  };

  const handleRetry = () => {
    reset();
  };

  // Map the worker's progress_stage value to the current "active" stage
  // index in our user-facing stage list. Returns -1 if the run hasn't
  // claimed/started yet (still in sync phase).
  const currentStageIndex = (s: typeof state): number => {
    let progressStage: string | null = null;
    if (s.kind === "validatePolling" || s.kind === "submitPolling") {
      progressStage = s.progressStage;
    }
    if (!progressStage) {
      // Pre-stage states map to "before stage 1" (no checkmarks yet).
      // Returning -1 means "the work hasn't reached any RPA stage".
      return -1;
    }
    const stages = s.kind === "submitPolling" ? RPA_STAGES_SUBMIT : RPA_STAGES_VALIDATE;
    const idx = stages.findIndex((st) => st.id === progressStage);
    return idx;
  };

  // Headline label for the progress panel.
  const progressHeadline = (s: typeof state): { title: string; sub?: string } => {
    if (s.kind === "validateSyncing")
      return { title: "Syncing cart to server", sub: `${s.itemsSynced} / ${s.itemsTotal} items` };
    if (s.kind === "validateStarting")
      return { title: "Validating against MLCC", sub: "Starting the RPA pipeline…" };
    if (s.kind === "validatePolling")
      return {
        title: "Validating against MLCC",
        sub: s.progressMessage ?? undefined,
      };
    if (s.kind === "submitStarting")
      return { title: "Submitting order to MLCC", sub: "Starting the RPA pipeline…" };
    if (s.kind === "submitPolling")
      return {
        title: "Submitting order to MLCC",
        sub: s.progressMessage ?? undefined,
      };
    return { title: "Working…" };
  };

  return (
    /*
      PAGE vs DRAWER shell (2026-07-26, the Cart-tab fix). In page mode the
      fixed dimmed backdrop becomes a plain static host (the /cart route IS
      the background), the sheet chrome (grab handle, close X, dialog
      semantics) disappears, and `drawer--cart-page` CSS un-sheets the
      container. The sibling modals below are position:fixed overlays, so
      they render identically from either host. Everything inside — the
      whole Check/Place machine — is byte-identical between modes.
    */
    <div
      className={isPage ? "cart-page-host" : "drawer-backdrop"}
      onClick={isPage ? undefined : handleClose}
      role={isPage ? undefined : "presentation"}
    >
      <div
        className={`drawer drawer--cart${isPage ? " drawer--cart-page" : ""}`}
        onClick={isPage ? undefined : (e) => e.stopPropagation()}
        role={isPage ? undefined : "dialog"}
        aria-modal={isPage ? undefined : true}
        aria-label="Cart"
      >
        {isPage ? null : <div className="drawer-grab" aria-hidden="true" />}
        <div className="drawer-header drawer-header--cart">
          <div className="drawer-header__titles">
            <h2>Cart</h2>
            {items.length > 0 && state.kind !== "submitDone" ? (
              <span className="drawer-header__meta">
                {items.length} product{items.length === 1 ? "" : "s"} ·{" "}
                {money(displayedTotal.value)}
                {displayedTotal.isMlccNet ? " · MLCC net" : ""}
              </span>
            ) : null}
          </div>
          {isPage ? null : (
            <button type="button" className="drawer-close" onClick={handleClose} aria-label="Close cart" disabled={isBusy}>
              <IconX size={20} />
            </button>
          )}
        </div>

        {/* ─── Cart contents (always visible unless in submit-done state) ─── */}
        {state.kind !== "submitDone" ? (
          <>
            {items.length === 0 ? (
              <p className="drawer-empty muted">Your cart is empty — scan items to add them</p>
            ) : (
              <div className="drawer-ada-groups">
                {groupedByAda.map((group) => {
                  const progressRatio = Math.min(group.liters / 9, 1);
                  const litersShort = Math.max(0, 9 - group.liters);
                  return (
                    <section key={group.adaNumber} className="drawer-ada-section">
                      <div className="drawer-ada-header">
                        <div className="drawer-ada-title">{group.adaName}</div>
                        <div className="drawer-ada-progress-text">
                          {group.liters.toFixed(2)} L / 9.00 L
                        </div>
                      </div>
                      <div className="drawer-ada-progress-track" aria-hidden="true">
                        <div
                          className={`drawer-ada-progress-fill ${group.meetsMinimum ? "is-met" : "is-short"}`}
                          style={{ width: `${progressRatio * 100}%` }}
                        />
                      </div>
                      {!group.meetsMinimum ? (
                        <p className="drawer-ada-needed">Need {litersShort.toFixed(2)} L more from this distributor</p>
                      ) : null}
                      <ul className="drawer-list">
                        {group.lines.map((line) => {
                          const unit = line.product.licensee_price ?? 0;
                          const lineTotal = unit * line.quantity;
                          const size =
                            line.product.bottle_size_label ?? `${line.product.bottle_size_ml ?? ""} ML`;
                          const lineId = cartLineId(line.product);
                          // Hoisted out of the qty-controls IIFE below so
                          // atMin can use it too. lineSmallestValid is what
                          // the `−` button bottoms out at (user must use
                          // trash icon to remove past that).
                          const lineRule = getOrderingRuleDisplay({
                            code: line.product.code,
                            bottle_size_ml: line.product.bottle_size_ml,
                            case_size: line.product.case_size,
                            ada_name: line.product.ada_name,
                            pack_count: line.product.pack_count,
                          });
                          const lineValid = generateValidQuantities(lineRule);
                          const lineConstrained = lineValid.length > 0;
                          const lineSmallestValid = lineConstrained ? lineValid[0] : 1;
                          const atMin = line.quantity <= lineSmallestValid;
                          const lineError = lineErrorFor(line.product.code);
                          const suggestions = lineError?.suggestedAlternatives ?? [];
                          return (
                            <li key={lineId} className="drawer-line">
                              <div className="drawer-line-main">
                                {/*
                                  Title is tappable IF onLineProductClick is wired
                                  (task #51, 2026-05-30). Opens the ProductCard for
                                  this bottle's family — Amazon-style sibling
                                  browsing without re-scanning. Disabled during
                                  busy states so a tap mid-validate doesn't open
                                  a new modal layer over the progress UI.
                                */}
                                {onLineProductClick ? (
                                  <button
                                    type="button"
                                    className="drawer-line-title drawer-line-title--tappable"
                                    onClick={() => onLineProductClick(line.product)}
                                    disabled={isBusy}
                                  >
                                    {line.product.name}
                                  </button>
                                ) : (
                                  <div className="drawer-line-title">{line.product.name}</div>
                                )}
                                <div className="muted small">
                                  {/*
                                    Container label rides the cart line
                                    (2026-07-11, family-tree plan §B): a
                                    non-glass bottle always says so —
                                    "375 ML · Plastic · #1505" — so glass
                                    vs plastic is never ambiguous between
                                    the chip and the confirm modal.
                                  */}
                                  {size}
                                  {nonGlassContainerSuffix(line.product.container)}
                                  {packCountSuffix(line.product.pack_count)} · #
                                  {line.product.code}
                                </div>
                                <div className="drawer-line-controls">
                                  {/*
                                    Cart-line quantity controls (2026-05-31
                                    fix for #45). +/− snap to valid MLCC
                                    quantities via useCart's stepLineQuantity
                                    helper; tapping the qty number opens a
                                    native dropdown of all valid amounts so
                                    the user can jump to 240 without 20 taps.
                                  */}
                                  <div className="qty-stepper" role="group" aria-label="Quantity">
                                    <button
                                      type="button"
                                      className="qty-stepper__btn"
                                      aria-label="Decrease quantity"
                                      disabled={atMin || isBusy}
                                      onClick={() => handleDecrement(lineId)}
                                    >
                                      −
                                    </button>
                                    {lineConstrained ? (
                                      <div className="qty-picker-wrap qty-picker-wrap--cart" aria-live="polite">
                                        <span className="qty-picker-display">{line.quantity}</span>
                                        <select
                                          className="qty-picker-select"
                                          value={line.quantity}
                                          disabled={isBusy}
                                          onChange={(e) =>
                                            handleUpdateQuantity(
                                              line.product.code,
                                              Number(e.target.value),
                                            )
                                          }
                                          aria-label="Quantity (tap to choose from valid amounts)"
                                        >
                                          {/*
                                            Include the line's current qty as
                                            a "(not valid)" option if it's
                                            not in the valid list (e.g. a
                                            cart saved before this shipped).
                                            Lets the user see what they have
                                            without the select silently
                                            snapping to a different value.
                                          */}
                                          {!lineValid.includes(line.quantity) ? (
                                            <option value={line.quantity}>
                                              {line.quantity} (not valid)
                                            </option>
                                          ) : null}
                                          {lineValid.map((q) => (
                                            <option key={q} value={q}>
                                              {q} bottles
                                            </option>
                                          ))}
                                        </select>
                                      </div>
                                    ) : (
                                      <span className="qty-stepper__value" aria-live="polite">
                                        {line.quantity}
                                      </span>
                                    )}
                                    <button
                                      type="button"
                                      className="qty-stepper__btn"
                                      aria-label="Increase quantity"
                                      disabled={isBusy}
                                      onClick={() => handleIncrement(lineId)}
                                    >
                                      +
                                    </button>
                                  </div>
                                  {/*
                                    Clean trash icon (task #52, 2026-05-30).
                                    Was: full-width red oval next to qty stepper that looked
                                    like an alarm button. Now: square icon button on the right
                                    edge with aria-label for screen readers + title tooltip.
                                  */}
                                  {/* #28: park the line for another week. */}
                                  <button
                                    type="button"
                                    className="cart-line-remove-btn cart-line-save-btn"
                                    disabled={isBusy}
                                    onClick={() => saveForLater(lineId)}
                                    aria-label={`Save ${line.product.name} for later`}
                                    title="Save for later"
                                  >
                                    <IconBookmark size={16} />
                                  </button>
                                  <button
                                    type="button"
                                    className="cart-line-remove-btn"
                                    disabled={isBusy}
                                    onClick={() => handleRemove(line.product.code)}
                                    aria-label={`Remove ${line.product.name} from cart`}
                                    title="Remove from cart"
                                  >
                                    <IconTrash size={16} />
                                  </button>
                                </div>
                                {lineError ? (
                                  <div className="drawer-line-error" role="alert">
                                    <span className="drawer-line-error-text">{lineError.reason}</span>
                                    {suggestions.length > 0 ? (
                                      <div className="drawer-line-suggestions">
                                        <span className="muted small">Fix:</span>
                                        {suggestions.map((alt) => (
                                          <button
                                            key={alt}
                                            type="button"
                                            className="drawer-line-suggestion"
                                            disabled={isBusy}
                                            onClick={() => handleUpdateQuantity(line.product.code, alt)}
                                          >
                                            Set to {alt}
                                          </button>
                                        ))}
                                      </div>
                                    ) : null}
                                  </div>
                                ) : null}
                              </div>
                              <div className="drawer-line-total">{money(lineTotal)}</div>
                            </li>
                          );
                        })}
                      </ul>
                      <div className="drawer-ada-subtotal">
                        <span>ADA subtotal</span>
                        <strong>{money(group.subtotalCost)}</strong>
                      </div>
                    </section>
                  );
                })}
              </div>
            )}

            {/* ─── #28 Saved for later (2026-08-10, Amazon-style) ───────── */}
            {savedItems.length > 0 ? (
              <section className="saved-later" aria-label="Saved for later">
                <div className="saved-later__head">
                  <IconBookmark size={15} aria-hidden />
                  <span>Saved for later ({savedItems.length})</span>
                </div>
                <ul className="saved-later__list">
                  {savedItems.map((line) => {
                    const id = `${line.product.code}::${line.product.ada_number}`;
                    return (
                      <li key={id} className="saved-later__row">
                        <div className="saved-later__info">
                          <span className="saved-later__name">{line.product.name}</span>
                          <span className="muted small">
                            {line.quantity} × {money(line.product.licensee_price ?? 0)}
                          </span>
                        </div>
                        <div className="saved-later__actions">
                          <button
                            type="button"
                            className="saved-later__btn"
                            disabled={isBusy}
                            onClick={() => moveSavedToCart(id)}
                          >
                            Move to cart
                          </button>
                          <button
                            type="button"
                            className="cart-line-remove-btn"
                            disabled={isBusy}
                            onClick={() => removeSaved(id)}
                            aria-label={`Remove ${line.product.name} from saved`}
                            title="Remove"
                          >
                            <IconTrash size={14} />
                          </button>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </section>
            ) : null}
          </>
        ) : null}

        {/* ─── Rule-engine validation messages ────────────────────────────── */}
        {items.length > 0 && state.kind !== "submitDone" ? (
          <>
            {validationResult?.ok === false ? (
              <p className="drawer-validation-notice muted">
                Couldn&apos;t verify this cart right now ({validationResult.error}). You can still validate against MLCC.
              </p>
            ) : null}
            {hasDefinitiveValidationFailure ? (
              <ul className="drawer-validation-errors">
                {validationBlockers.map((blocker) => (
                  <li key={blocker}>{blocker}</li>
                ))}
              </ul>
            ) : null}
          </>
        ) : null}

        {/*
          Instant rule verdict during a validate run. The local rule-engine
          check already ran (debounced on cart change), so the moment the user
          taps Validate we can INSTANTLY confirm the cart passes MLCC's rules
          while the slower live MLCC availability check runs underneath. Turns
          the wait from a dead spinner into immediate positive feedback —
          Tony's "validate should feel instant" ask (2026-06-07).
        */}
        {isBusy &&
        (state.kind === "validateSyncing" ||
          state.kind === "validateStarting" ||
          state.kind === "validatePolling") &&
        validationResult?.ok &&
        validationResult.valid ? (
          <div className="banner banner-ok banner--flex" style={{ marginBottom: 8 }}>
            <IconCheck size={15} strokeWidth={2.25} className="banner__icon" />
            <span>
              Your cart passes MLCC rules — now confirming live availability
              with MLCC.
            </span>
          </div>
        ) : null}

        {/* ─── Async progress (validate OR submit) ───────────────────────── */}
        {isBusy ? (
          <RpaProgressPanel
            headline={progressHeadline(state)}
            stages={
              state.kind === "submitStarting" || state.kind === "submitPolling"
                ? RPA_STAGES_SUBMIT
                : RPA_STAGES_VALIDATE
            }
            currentStageIndex={currentStageIndex(state)}
            preStage={
              state.kind === "validateSyncing" ||
              state.kind === "validateStarting" ||
              state.kind === "submitStarting"
            }
            startedAtMs={
              state.kind === "validatePolling" || state.kind === "submitPolling"
                ? state.startedAtMs
                : undefined
            }
          />
        ) : null}

        {/*
          "Start over" escape hatch (2026-06-26). Rendered only while a
          validate poll is stuck past STUCK_RETRY_THRESHOLD_SEC, OR while a
          recover notice from a just-completed recover is still relevant
          (idle after a successful clear, or validatePolling for the warn
          branches). The button calls the existing recoverStore() — never the
          raw endpoint — and handleStartOver branches honestly on the
          response. See the five-branch contract in handleStartOver. Styles
          are inline (no new CSS classes) since this file is the only
          stylesheet-adjacent surface we may touch.
        */}
        {showStartOver ||
        (recoverState.kind !== "idle" &&
          (state.kind === "idle" || state.kind === "validatePolling")) ? (
          <div style={{ marginTop: 8, marginBottom: 4 }}>
            {showStartOver ? (
              <button
                type="button"
                className="btn btn-block"
                disabled={recoverState.kind === "working"}
                onClick={() => void handleStartOver()}
                style={{
                  background: "transparent",
                  border: "1px solid var(--lk-border, #d1d5db)",
                  color: "var(--lk-text-muted, #6b7280)",
                  fontSize: 13,
                }}
              >
                {recoverState.kind === "working"
                  ? "Starting over…"
                  : "Taking too long? Start over"}
              </button>
            ) : null}
            {recoverState.kind === "notice" ? (
              <p
                className={`drawer-note${
                  recoverState.tone === "ok"
                    ? " drawer-note--ok"
                    : recoverState.tone === "err"
                      ? " drawer-note--err"
                      : ""
                }`}
                style={{ marginTop: showStartOver ? 8 : 0 }}
              >
                {recoverState.tone === "ok" ? (
                  <IconCheck size={14} strokeWidth={2.25} />
                ) : recoverState.tone === "err" ? (
                  <IconAlert size={14} />
                ) : null}
                <span>{recoverState.text}</span>
              </p>
            ) : null}
          </div>
        ) : null}

        {/* ─── Validate result panel (after successful MLCC validate) ────── */}
        {state.kind === "validateDone" && state.finalStatus === "succeeded" ? (
          <ValidateResultPanel
            result={state.validateResult}
            /*
              canCheckout for the BANNER is the AND of MILO's flag and
              our inferred-OOS check. When inferredOos is non-empty we
              want the warn-yellow banner + "review issues below"
              headline, not the green "ready for checkout" lie.
            */
            canCheckout={
              (state.validateResult?.can_checkout ?? null) === true &&
              serverOosCodes.size === 0 &&
              inferredOos.length === 0
            }
            cartItems={items}
            onRemoveOosAndRecheck={
              oosCodesForRecheck.size > 0 ? removeOosAndRecheck : null
            }
            removeBusy={isFiring}
          />
        ) : null}

        {state.kind === "validateDone" && state.finalStatus !== "succeeded" ? (
          <RunFailureCard
            failureType={state.failureType}
            failureMessage={state.failureMessage}
            onRetryValidate={() => void startValidate(items)}
            onOpenSettings={() => navigate("/settings")}
          />
        ) : null}

        {/* ─── Action buttons (idle / validateDone) ───────────────────────── */}
        {(state.kind === "idle" || state.kind === "validateDone") && items.length > 0 ? (
          <>
            {/*
              "Clear scanner cart" — clears LOCAL + LK server cart only.
              MILO's actual cart state lives in their session and won't
              empty until the next validate/submit run (Stage 3's auto-
              clear-cart pre-flight, task #9). The caption below tells
              the user this honestly. Bug found 2026-05-30: Tony hit
              "Clear cart" and MLCC still showed Tito's + Ciroc on the
              website — because we'd only ever cleared the scanner side.
              True MILO clear is task #56 (deferred — it costs an RPA
              run and most users don't actually need it between orders).
            */}
            {/*
              Order template controls (task #72). Shown above the
              Clear / Reset buttons so the "save this for next week"
              prompt sits next to the cart contents, not buried with
              destructive actions.
            */}
            <div className="drawer-tools">
              {items.length > 0 ? (
                <button
                  type="button"
                  className="drawer-tool"
                  disabled={isBusy}
                  onClick={() => {
                    // Pre-fill name with day-of-week (e.g. "Thursday order")
                    // — matches dad's actual weekly pattern.
                    const day = new Date().toLocaleDateString("en-US", {
                      weekday: "long",
                    });
                    setSaveTemplateName(`${day} order`);
                    setShowSaveTemplate(true);
                  }}
                >
                  <IconFileText size={15} />
                  <span>Save template</span>
                </button>
              ) : null}
              {templates.length > 0 ? (
                <button
                  type="button"
                  className="drawer-tool"
                  disabled={isBusy || templateLoading !== null}
                  onClick={() => setShowTemplatePicker(true)}
                >
                  <IconClipboardList size={15} />
                  <span>
                    Load template
                    {templates.length > 1 ? ` (${templates.length})` : ""}
                  </span>
                </button>
              ) : null}
            </div>
            {templateLoadResult ? (
              <p className="drawer-note drawer-note--ok">
                <IconCheck size={14} strokeWidth={2.25} />
                <span>
                  Loaded &quot;{templateLoadResult.name}&quot; — added{" "}
                  {templateLoadResult.addedCount} items
                  {templateLoadResult.missingCount > 0
                    ? `, skipped ${templateLoadResult.missingCount} no longer in MLCC catalog`
                    : ""}
                </span>
              </p>
            ) : null}
            {templateError ? (
              <p className="drawer-note drawer-note--err">
                <IconAlert size={14} />
                <span>Template error: {templateError}</span>
              </p>
            ) : null}
            {/*
              Single "Clear cart" button (2026-06-07, Tony's call).
              Tony was right that two buttons was confusing — the
              scanner cart and MILO cart are conceptually one thing to
              the user. handleMlccReset opens a confirm modal first,
              then runs the RPA clear, and clearCart() (local) is
              called on success. One button, one mental model, with a
              proper "are you sure" gate.
            */}
            <button
              type="button"
              className="drawer-clear-btn"
              disabled={mlccResetState.kind === "running"}
              onClick={() => void handleMlccReset()}
            >
              <IconTrash size={14} />
              <span>
                {mlccResetState.kind === "running"
                  ? "Clearing cart…"
                  : "Clear cart"}
              </span>
            </button>
            {mlccResetState.kind === "running" ? (
              <p className="drawer-note">
                Your cart is already empty. We&apos;re finishing up on MILO&apos;s
                side — keep working, this will finish on its own.
              </p>
            ) : null}
            {mlccResetState.kind === "done" ? (
              <p className="drawer-note drawer-note--ok">
                <IconCheck size={14} strokeWidth={2.25} />
                <span>
                  MLCC cart {mlccResetState.cleared ? `emptied (${mlccResetState.itemCount} item${mlccResetState.itemCount === 1 ? "" : "s"})` : "was already empty"}
                </span>
              </p>
            ) : null}
            {mlccResetState.kind === "error" ? (
              <div className="drawer-note drawer-note--err">
                <IconAlert size={14} />
                <span>
                  {mlccResetState.message}
                  <button
                    type="button"
                    className="drawer-note__dismiss"
                    onClick={() => setMlccResetState({ kind: "idle" })}
                  >
                    Dismiss
                  </button>
                </span>
              </div>
            ) : null}
          </>
        ) : null}

        {/* ─── Sticky checkout footer: total + Validate / Submit ─────────────
          *
          * Premium overhaul 2026-06-10. The total + the two CTAs live in a
          * sticky footer pinned to the bottom of the sheet, checkout-style.
          * Render conditions preserve the prior behavior exactly:
          *   - footer (total) shows whenever the cart has items and we're
          *     not in the submit-done terminal state
          *   - the Validate / Submit buttons render ONLY in idle /
          *     validateDone — same as the old stacked-button block
          */}
        {items.length > 0 && state.kind !== "submitDone" ? (
          <>
            {/*
              Fire-error surface (P1b). The run never started (sync/trigger
              failed before a runId came back), so there's no pill to show —
              surface it inline near the footer so the user can retry.
            */}
            {fireError ? <div className="banner banner-err">{fireError}</div> : null}
            {/*
              Pinned check-result strip (TONY-WANTS 7/16 #2): "post-validate
              results posted in the cart all the way at the bottom." The full
              panel lives up in the body where it can scroll away; this strip
              sits ON the footer so the OOS verdict and the one-tap fix are
              in view exactly where the operator is about to press buttons.
            */}
            {state.kind === "validateDone" && oosCodesForRecheck.size > 0 ? (
              <div className="banner banner-warn" style={{ marginBottom: 8 }}>
                <strong>
                  {oosCodesForRecheck.size} item{oosCodesForRecheck.size === 1 ? "" : "s"} out of
                  stock at MLCC
                </strong>
                <div className="muted small" style={{ marginTop: 4 }}>
                  {(() => {
                    const names = [...oosCodesForRecheck]
                      .map((code) => oosDisplayLabel({ code }, items))
                      .filter((n) => n !== "");
                    const shown = names.slice(0, 3).join(", ");
                    const more = names.length - 3;
                    return more > 0 ? `${shown}, and ${more} more` : shown;
                  })()}
                </div>
                <button
                  type="button"
                  className="btn btn-block"
                  disabled={isFiring}
                  onClick={removeOosAndRecheck}
                  style={{ marginTop: 8 }}
                >
                  {isFiring
                    ? "Working…"
                    : `Remove ${
                        oosCodesForRecheck.size === 1
                          ? "it"
                          : `these ${oosCodesForRecheck.size}`
                      } and check again`}
                </button>
              </div>
            ) : null}
            <div className="drawer-footer">
              <div className="drawer-footer__total">
                <span className="drawer-footer__total-label">
                  {displayedTotal.label}
                </span>
                <strong className="drawer-footer__total-value">
                  {money(displayedTotal.value)}
                </strong>
              </div>
              {/*
                Two-step Check → SEE → Place (2026-07-11, Tony's 2026-07-01
                design). ARMED: two explicit buttons — "Check with MLCC"
                fires a validate_only directly (non-destructive, no modal);
                "Place Order" opens the line-by-line confirm modal and is
                LOCKED unless the last green check is fresh (<10 min) for
                this byte-identical cart (resolvePlaceGate — any edit
                re-locks via hash mismatch). PRACTICE: the single Check
                button, now also direct-fire; the confirm modal is reserved
                for placing. Server gates re-validate regardless.
              */}
              {state.kind === "idle" || state.kind === "validateDone" ? (
                submissionArmed ? (
                  <>
                    <div className="drawer-footer__actions">
                      <button
                        type="button"
                        className="btn btn-block"
                        disabled={!canPlaceOrder}
                        onClick={() => fireRun("validate_only")}
                        title={
                          !rulesValid
                            ? "Fix the issues above before checking"
                            : undefined
                        }
                      >
                        {isFiring
                          ? "Working…"
                          : orderInFlight
                            ? "Run in progress…"
                            : "Check with MLCC"}
                      </button>
                      <button
                        type="button"
                        className="btn primary btn-block"
                        disabled={!placeGate.ready}
                        onClick={() => {
                          setFireError(null);
                          setConfirmSubmit(true);
                        }}
                        title={placeGate.ready ? undefined : placeGate.reason}
                      >
                        Place Order
                      </button>
                    </div>
                    {/*
                      One honest sentence on the Place lock state — the
                      reason is never a mystery (doctrine §16). When ready,
                      say what MILO blessed and when.
                    */}
                    <p className="drawer-place-hint muted small" role="status">
                      {placeGate.ready
                        ? placeGate.checkedAgoMs < 60_000
                          ? "Checked just now — cart matches MILO."
                          : `Checked ${Math.round(placeGate.checkedAgoMs / 60_000)} min ago — cart matches MILO.`
                        : placeGate.reason}
                    </p>
                  </>
                ) : (
                  <button
                    type="button"
                    className="btn primary btn-block"
                    disabled={!canPlaceOrder}
                    onClick={() => fireRun("validate_only")}
                    title={
                      !rulesValid
                        ? "Fix the issues above before checking"
                        : undefined
                    }
                  >
                    {isFiring
                      ? "Checking…"
                      : orderInFlight
                        ? "Check in progress…"
                        : "Check Order"}
                  </button>
                )
              ) : null}
            </div>
          </>
        ) : null}

        {/* ─── Submit terminal states ─────────────────────────────────────── */}
        {/*
          AUDIT #15 (P0, 2026-06-12): "succeeded" alone is NOT proof an
          order was placed — the Stage-5 triple gate can downgrade a
          submit to dry_run and the run still finalizes succeeded. The
          green banner (and the cart clear!) now require the worker's
          explicit submitted=true. A prepared-but-not-submitted run shows
          the amber truth and PRESERVES the cart for retry once armed.
        */}
        {state.kind === "submitDone" &&
        state.finalStatus === "succeeded" &&
        state.submitResult?.submitted === true ? (
          <>
            <div className="banner banner-ok">
              Order submitted to MILO
              {Array.isArray(state.submitResult.confirmation_numbers) &&
              state.submitResult.confirmation_numbers.length > 0
                ? ` — ${state.submitResult.confirmation_numbers.length} confirmation${
                    state.submitResult.confirmation_numbers.length === 1 ? "" : "s"
                  } received.`
                : ". Check the Orders page for confirmation numbers."}
            </div>
            <button
              type="button"
              className="btn primary btn-block"
              onClick={() => {
                reset();
                clearCart();
                onClose();
              }}
            >
              Done
            </button>
          </>
        ) : null}

        {state.kind === "submitDone" &&
        state.finalStatus === "succeeded" &&
        state.submitResult?.submitted !== true ? (
          <>
            <div className="banner banner-warn">
              <strong>Nothing was ordered.</strong>{" "}
              {allowOrderSubmission
                ? "MILO accepted the cart as a practice run, but live ordering isn’t switched on for this store yet — your order was NOT submitted."
                : "As shown before you confirmed, this store isn’t approved for live orders yet — MILO checked the cart and pricing as a preview, but nothing was submitted."}{" "}
              Your cart is saved right here.
            </div>
            {state.submitResult?.dry_run_reason ? (
              <details className="drawer-run-failure__detail">
                <summary>Technical detail</summary>
                <p>{state.submitResult.dry_run_reason}</p>
              </details>
            ) : null}
            <button
              type="button"
              className="btn btn-block"
              onClick={() => {
                reset();
                onClose();
              }}
            >
              Close — keep my cart
            </button>
          </>
        ) : null}

        {state.kind === "submitDone" && state.finalStatus !== "succeeded" ? (
          <RunFailureCard
            failureType={state.failureType}
            failureMessage={state.failureMessage}
            onRetryValidate={() => void startValidate(items)}
            onOpenSettings={() => navigate("/settings")}
          />
        ) : null}

        {state.kind === "error" ? (
          <>
            <div className="banner banner-err">{state.message}</div>
            <button type="button" className="btn secondary btn-block" onClick={handleRetry}>
              Back to cart
            </button>
            <button type="button" className="btn btn-block" onClick={onClose}>
              Close
            </button>
          </>
        ) : null}
      </div>

      {/* ─── Save template modal (task #72) ─────────── */}
      {showSaveTemplate ? (
        <div
          className="confirm-overlay"
          role="dialog"
          aria-modal="true"
          aria-label="Save cart as template"
          onClick={() => !saveTemplateBusy && setShowSaveTemplate(false)}
        >
          <div className="confirm-card" onClick={(e) => e.stopPropagation()}>
            <h2 className="confirm-title">Save as template?</h2>
            <p className="confirm-body">
              Save these {items.length} items as a reusable template you can
              load back into your cart next time.
            </p>
            <input
              type="text"
              className="search-bar-input"
              placeholder="Template name (e.g. Thursday order)"
              value={saveTemplateName}
              onChange={(e) => setSaveTemplateName(e.target.value)}
              maxLength={80}
              autoFocus
              style={{ width: "100%", marginBottom: 12 }}
            />
            {/*
              Schedule picker (task #75). Optional — null means "manual
              load only." When set, the daily cron marks this template
              "ready to review" every matching day, and a banner shows
              up on the scanner home.
            */}
            <div className="tpl-schedule">
              <div className="tpl-schedule__label">
                Auto-prepare this template every:
              </div>
              <div className="tpl-schedule__chips">
                <button
                  type="button"
                  className={`browse-chip${saveTemplateDow === null ? " browse-chip--active" : ""}`}
                  onClick={() => setSaveTemplateDow(null)}
                >
                  Never (manual)
                </button>
                {[
                  { dow: 0, label: "Sun" },
                  { dow: 1, label: "Mon" },
                  { dow: 2, label: "Tue" },
                  { dow: 3, label: "Wed" },
                  { dow: 4, label: "Thu" },
                  { dow: 5, label: "Fri" },
                  { dow: 6, label: "Sat" },
                ].map((d) => (
                  <button
                    key={d.dow}
                    type="button"
                    className={`browse-chip${saveTemplateDow === d.dow ? " browse-chip--active" : ""}`}
                    onClick={() => setSaveTemplateDow(d.dow)}
                  >
                    {d.label}
                  </button>
                ))}
              </div>
              {saveTemplateDow !== null ? (
                <p className="muted small" style={{ marginTop: 6, marginBottom: 0 }}>
                  Each{" "}
                  {[
                    "Sunday",
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday",
                    "Saturday",
                  ][saveTemplateDow]}{" "}
                  morning, you&apos;ll see a &quot;ready to review&quot; banner
                  on the scanner home with this template loaded.
                </p>
              ) : null}
            </div>
            <div className="confirm-actions">
              <button
                type="button"
                className="btn secondary"
                onClick={() => setShowSaveTemplate(false)}
                disabled={saveTemplateBusy}
              >
                Cancel
              </button>
              <button
                type="button"
                className="btn primary"
                onClick={() => void handleSaveTemplate()}
                disabled={saveTemplateBusy || !saveTemplateName.trim()}
              >
                {saveTemplateBusy ? "Saving…" : "Save template"}
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {/* ─── Load template picker (task #72) ─────────── */}
      {showTemplatePicker ? (
        <div
          className="confirm-overlay"
          role="dialog"
          aria-modal="true"
          aria-label="Pick template to load"
          onClick={() => setShowTemplatePicker(false)}
        >
          <div
            className="confirm-card"
            onClick={(e) => e.stopPropagation()}
            style={{ maxWidth: 480, maxHeight: "70vh", overflow: "auto" }}
          >
            <h2 className="confirm-title">Load saved template</h2>
            <p className="confirm-body" style={{ marginBottom: 12 }}>
              Items from the template will be added to your current cart.
              {items.length > 0
                ? " Existing cart items stay; quantities of overlapping codes add together."
                : ""}
            </p>
            <ul className="tpl-list">
              {templates.map((tpl) => (
                <li key={tpl.id} className="tpl-item">
                  <div className="tpl-item__head">
                    <strong>{tpl.name}</strong>
                    <span className="muted small">
                      {tpl.items.length} item{tpl.items.length === 1 ? "" : "s"}
                    </span>
                  </div>
                  <div className="tpl-item__meta muted small">
                    {tpl.last_loaded_at ? (
                      <span>Last used {new Date(tpl.last_loaded_at).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span>
                    ) : null}
                    {tpl.schedule_dow !== null ? (
                      <span className="tpl-badge tpl-badge--auto">
                        <IconCalendar size={12} />
                        Auto every{" "}
                        {[
                          "Sun",
                          "Mon",
                          "Tue",
                          "Wed",
                          "Thu",
                          "Fri",
                          "Sat",
                        ][tpl.schedule_dow]}
                      </span>
                    ) : null}
                    {tpl.needs_review ? (
                      <span className="tpl-badge tpl-badge--ready">
                        <span className="tpl-dot" aria-hidden="true" />
                        Ready to review
                      </span>
                    ) : null}
                  </div>
                  <button
                    type="button"
                    className="btn primary btn-block"
                    onClick={() => void handleLoadTemplate(tpl.id)}
                    disabled={templateLoading !== null}
                  >
                    {templateLoading === tpl.id ? "Loading…" : "Load into cart"}
                  </button>
                </li>
              ))}
            </ul>
            <button
              type="button"
              className="btn secondary btn-block"
              style={{ marginTop: 12 }}
              onClick={() => setShowTemplatePicker(false)}
            >
              Cancel
            </button>
          </div>
        </div>
      ) : null}

      {/* ─── MLCC reset confirm modal (task #57) ─────────── */}
      {mlccResetState.kind === "confirm" ? (
        <div
          className="confirm-overlay"
          role="dialog"
          aria-modal="true"
          aria-label="Confirm MLCC cart reset"
          onClick={() => setMlccResetState({ kind: "idle" })}
        >
          <div className="confirm-card" onClick={(e) => e.stopPropagation()}>
            <h2 className="confirm-title">Clear cart?</h2>
            <p className="confirm-body">
              This empties both your scanner cart AND your MILO cart.
              Runs a real session against MILO and clicks Clear Cart
              there — takes about 30-60 seconds. Once it&apos;s done
              the cart is empty on both sides. Can&apos;t be undone.
            </p>
            <div className="confirm-actions">
              <button
                type="button"
                className="btn secondary"
                onClick={() => setMlccResetState({ kind: "idle" })}
              >
                Cancel
              </button>
              <button
                type="button"
                className="btn primary"
                onClick={() => void confirmMlccReset()}
              >
                Clear cart
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {/* ─── Pre-submit verification modal (task #89, 2026-06-07) ─────────────
        *
        * Discipline #3 of the LK Integrity Doctrine in action — pre-commit
        * verification with the FULL cart in plain English. Tony locked this
        * pattern on 2026-06-07: no opt-out, ever. The yes/no popup that used
        * to live here was insufficient — it added a tap but didn't catch
        * integrity bugs. The line-by-line summary catches them because the
        * user sees the actual order in their own language and can stop if
        * anything looks wrong (wrong UPC mapping, phantom cart from a
        * background pre-validate, vision picker picking the wrong bottle).
        */}
      {confirmSubmit ? (
        <SubmitConfirmationModal
          items={items}
          subtotal={totalCost}
          /*
           * validateResult only exists on a subset of SubmissionState
           * variants (validateDone, plus the in-flight submit states
           * that carry it forward). Type-narrow conservatively — if
           * we don't have it, the modal falls back to subtotal-only.
           * In practice this is null only when Submit is somehow
           * clicked without a successful Validate, which the UI
           * already gates against.
           */
          orderSummary={
            "validateResult" in state ? state.validateResult?.order_summary ?? null : null
          }
          storeName={storeName ?? null}
          storeLicense={storeLicense ?? null}
          allowOrderSubmission={submissionArmed}
          onCancel={() => setConfirmSubmit(false)}
          onConfirm={() => {
            setConfirmSubmit(false);
            /*
              Two-step (2026-07-11): the modal is now reachable only from
              "Place Order" (armed), so this fires the submit path through
              the shared fireRun — which records the cart hash with the
              tracker and closes the drawer for the pill. The unarmed
              ternary is a belt: if the modal somehow opens in practice
              mode, it fires a harmless check (stages 1-4, never Stage 5).
              Server re-gates env + store + checkout regardless. Do NOT
              clearCart — the run is dry-run-gated and may not actually
              place; the cart must survive until a confirmed placement.
            */
            fireRun(submissionArmed ? "submit" : "validate_only");
          }}
        />
      ) : null}
    </div>
  );
}

/**
 * Renders the live MILO cart state after a successful validate_only run.
 * Shows: in-stock count, out-of-stock items (full list), totals, validate
 * messages from MILO. This is the user's "here's what MILO sees" view
 * before they commit to submitting.
 *
 * Iteration 2 (2026-05-30): Tony found that MILO's actual OOS-section
 * items weren't being surfaced — Stage 3 incorrectly verifies them as
 * "added", Stage 4 doesn't populate out_of_stock_items, and the user
 * just saw a yellow banner with no explanation. Fix:
 *
 *   (a) Surface ada_breakdown.errors — MILO's actual error messages
 *       per ADA ("You must order at least nine liters from this
 *       distributor"). The most informative field we have.
 *   (b) Compute "inferred OOS" by diffing the user's local cart against
 *       ada_breakdown items. Anything the user added but MILO's active
 *       orders don't show is almost certainly in MILO's OOS section.
 *   (c) Show per-ADA progress against the 9L minimum so user can see
 *       which distributor is under.
 *
 * (b) is a stopgap until the proper Stage 3/4 OOS detection ships — but
 * it works with the data we already have.
 */
function ValidateResultPanel({
  result,
  canCheckout,
  cartItems,
  onRemoveOosAndRecheck = null,
  removeBusy = false,
}: {
  result: import("../api/execution").ValidateResult | null;
  canCheckout: boolean | null;
  cartItems: CartContextValue["items"];
  /** TONY-WANTS 7/16 #0: one-tap strip-the-rejects-and-recheck. Null hides the button. */
  onRemoveOosAndRecheck?: (() => void) | null;
  removeBusy?: boolean;
}) {
  if (!result) {
    return (
      <div className="banner banner-warn">
        MLCC validate finished but no result data was returned. Re-validate to retry.
      </div>
    );
  }
  const oos = Array.isArray(result.out_of_stock_items) ? result.out_of_stock_items : [];
  const rejected = Array.isArray(result.items_rejected) ? result.items_rejected : [];
  const messages = Array.isArray(result.validate_messages) ? result.validate_messages : [];
  const errors = Array.isArray(result.validate_errors) ? result.validate_errors : [];
  const summary = result.order_summary ?? null;
  const adaBreakdown = Array.isArray(result.ada_breakdown) ? result.ada_breakdown : [];

  // Collect every error string MILO reported per ADA. These are the
  // human-readable messages MILO itself shows (e.g. "You must order at
  // least nine liters from this distributor"). De-duped.
  const milccErrors = new Set<string>();
  for (const ada of adaBreakdown) {
    const adaErrors = Array.isArray((ada as { errors?: unknown[] }).errors)
      ? ((ada as { errors: unknown[] }).errors as unknown[])
      : [];
    for (const e of adaErrors) {
      const s = typeof e === "string" ? e.trim() : "";
      // Filter junk: pure numbers, single chars (MILO sometimes echoes
      // the liter count alongside the message).
      if (s.length > 3 && !/^\d+(\.\d+)?$/.test(s)) milccErrors.add(s);
    }
  }
  const milccErrorList = [...milccErrors];

  // Inferred OOS — uses the shared helper so the panel and the parent
  // CartDrawer see the same list (parent uses it to gate Submit; we
  // use it here to render the "Likely out of stock" block).
  //
  // 2026-06-04 #53: after server-side validate_demoted detection,
  // anything Stage 4 lost track of already shows up in the `oos` list
  // above. Filter those codes out here so the same item doesn't
  // render twice. The inferred block stays visible ONLY when the
  // server missed something — a parser-regression alarm bell rather
  // than the primary signal.
  const serverOosCodeSet = getServerOosCodes(result);
  const inferredOos = computeInferredOos(cartItems, result).filter(
    (line) => !serverOosCodeSet.has(line.product.code),
  );

  // Per-ADA liter progress (only shown when at least one ADA is under).
  const adaProgress = adaBreakdown
    .filter((ada) => (ada as { meetsMinimum?: boolean }).meetsMinimum === false)
    .map((ada) => {
      const a = ada as {
        adaName?: string;
        adaNumber?: string;
        subtotalLiters?: number;
        meetsMinimum?: boolean;
      };
      return {
        name: a.adaName ?? `ADA ${a.adaNumber ?? "?"}`,
        liters: typeof a.subtotalLiters === "number" ? a.subtotalLiters : 0,
        shortBy: Math.max(0, 9 - (typeof a.subtotalLiters === "number" ? a.subtotalLiters : 0)),
      };
    });

  return (
    <div className={`banner ${canCheckout ? "banner-ok" : "banner-warn"}`}>
      <div className="vr-headline">
        {canCheckout ? (
          <IconCheck size={16} strokeWidth={2.25} className="vr-headline__icon" />
        ) : (
          <IconAlert size={16} className="vr-headline__icon" />
        )}
        <strong>
          {canCheckout
            ? "MLCC says: cart is ready for checkout."
            : "MLCC validate completed — review issues below before submitting."}
        </strong>
      </div>
      {/*
        Note: do NOT use .drawer-validation-errors here. That class is
        hard-styled with color: #fecaca (light red) because it was built
        for the cart's rule-engine error list. On the green success
        banner, red bullets look broken. We use the
        .banner-content-list class (defined in index.css alongside this
        component) which inherits the banner's text color so success
        messages render in the right tone.
      */}
      {messages.length > 0 ? (
        <ul className="banner-content-list" style={{ marginTop: 8 }}>
          {messages.map((m, i) => (
            <li key={i}>{m}</li>
          ))}
        </ul>
      ) : null}
      {errors.length > 0 ? (
        <ul className="banner-content-list" style={{ marginTop: 8 }}>
          {errors.map((e, i) => (
            <li key={i}>{e}</li>
          ))}
        </ul>
      ) : null}
      {oos.length > 0 ? (
        <>
          <div className="vr-heading">
            Out of stock at MLCC ({oos.length} item{oos.length === 1 ? "" : "s"}):
          </div>
          {/* OOS items DO use the red error class — they're real problems */}
          <ul className="drawer-validation-errors">
            {oos.map((item, i) => (
              <li key={i}>
                {/* TONY-WANTS 7/16 #1: cart-joined name — never a naked code */}
                {oosDisplayLabel(item, cartItems)}
                {item.quantity ? ` × ${item.quantity}` : ""}
                {/*
                  Reason-tagged messages from #53 (2026-06-04):
                    - "oos_section": MILO put it in its dedicated OOS
                      section after the add. The cleanest signal.
                    - "validate_demoted": MILO accepted the add but
                      silently dropped the item by the time we hit
                      Validate. Less clear-cut — may be stock, may be
                      a transient MILO state.
                  Anything else falls back to the raw reason string
                  for forward-compat.
                */}
                {item.reason === "oos_section"
                  ? " — marked out-of-stock by MILO"
                  : item.reason === "validate_demoted"
                    ? " — dropped during MILO validate (likely out of stock)"
                    : item.reason
                      ? ` — ${item.reason}`
                      : ""}
              </li>
            ))}
          </ul>
          {onRemoveOosAndRecheck ? (
            /*
              TONY-WANTS 7/16 #0 — the button that replaces hand-hunting
              8 codes out of a 34-line cart mid-order. Strips exactly the
              rejected lines and fires a fresh check; Place stays locked
              until that check comes back green (gate untouched).
            */
            <button
              type="button"
              className="btn btn-block"
              disabled={removeBusy}
              onClick={onRemoveOosAndRecheck}
              style={{ marginTop: 8 }}
            >
              {removeBusy
                ? "Working…"
                : `Remove ${oos.length === 1 ? "it" : `these ${oos.length}`} and check again`}
            </button>
          ) : (
            <p className="muted small" style={{ marginTop: 6 }}>
              Remove these from your cart and re-validate to clear.
            </p>
          )}
        </>
      ) : null}
      {/*
        Items REJECTED by MLCC during Stage 3 add-to-cart. Different from
        OOS: MILO actively refused to add these (validation rule violation,
        unknown code, MILO-side error, etc.). Without this list the user
        sees a yellow 'review issues below' banner but no explanation of
        what's wrong. Added 2026-05-30 to close that UX gap.
      */}
      {rejected.length > 0 ? (
        <>
          {/*
            Split the rejected list into "timed out" vs "hard rejected"
            (2026-06-01 fix for #61). Tony's Tito's 750ml flake was
            ALWAYS a Stage 3 timeout — MILO was slow rendering the
            quick-add row, we gave up after 8s, the line ended up in
            items_rejected with a misleading "did not appear" reason.
            Treating that as a hard rejection scares the user; treating
            it as a transient flake lets them re-validate and move on.
            The 8s wait was bumped to 18s in the worker too — this UI
            split is the user-facing complement.
          */}
          {(() => {
            const rejectedTyped = rejected as Array<{
              code?: string;
              productName?: string;
              quantity?: number;
              reason?: string;
            }>;
            const timedOut = rejectedTyped.filter((r) =>
              isStage3TimeoutRejection(r.reason),
            );
            const hard = rejectedTyped.filter(
              (r) => !isStage3TimeoutRejection(r.reason),
            );
            return (
              <>
                {timedOut.length > 0 ? (
                  <>
                    <div className="vr-heading">
                      MLCC didn&apos;t finish adding ({timedOut.length} item
                      {timedOut.length === 1 ? "" : "s"}):
                    </div>
                    <ul className="banner-content-list">
                      {timedOut.map((it, i) => (
                        <li key={`to-${i}`}>
                          {it.productName ?? it.code ?? "Unknown item"}
                          {it.quantity ? ` × ${it.quantity}` : ""}
                        </li>
                      ))}
                    </ul>
                    <p className="muted small" style={{ marginTop: 6 }}>
                      MLCC was slow responding for these. Tap{" "}
                      <strong>Re-validate against MLCC</strong> — it usually
                      goes through the second time.
                    </p>
                  </>
                ) : null}
                {hard.length > 0 ? (
                  <>
                    <div className="vr-heading">
                      Rejected by MLCC ({hard.length} item
                      {hard.length === 1 ? "" : "s"}):
                    </div>
                    <ul className="drawer-validation-errors">
                      {hard.map((it, i) => (
                        <li key={`h-${i}`}>
                          {it.productName ?? it.code ?? "Unknown item"}
                          {it.quantity ? ` × ${it.quantity}` : ""}
                          {it.reason ? ` — ${it.reason}` : ""}
                        </li>
                      ))}
                    </ul>
                    <p className="muted small" style={{ marginTop: 6 }}>
                      Remove these from your cart and re-validate to clear.
                    </p>
                  </>
                ) : null}
              </>
            );
          })()}
        </>
      ) : null}
      {/*
        Inferred OOS: items the user added that MILO's active orders don't
        show. Almost always means MILO put them in its own OOS section
        even though Stage 3 thought it added them. Stopgap until Stage
        3/4 OOS detection ships properly — but works with what we have.
      */}
      {inferredOos.length > 0 ? (
        <>
          <div className="vr-heading">
            Likely out of stock at MLCC ({inferredOos.length} item{inferredOos.length === 1 ? "" : "s"}):
          </div>
          <ul className="drawer-validation-errors">
            {inferredOos.map((line) => (
              <li key={cartLineId(line.product)}>
                {line.product.name}
                {line.quantity ? ` × ${line.quantity}` : ""}
                {line.product.bottle_size_label
                  ? ` (${line.product.bottle_size_label}${nonGlassContainerSuffix(line.product.container)}${packCountSuffix(line.product.pack_count)})`
                  : ""}
              </li>
            ))}
          </ul>
          <p className="muted small" style={{ marginTop: 6 }}>
            MLCC accepted the order but didn&apos;t show these on the cart —
            usually means they&apos;re in MLCC&apos;s out-of-stock section. Remove
            them and re-validate.
          </p>
        </>
      ) : null}
      {/*
        Per-ADA progress for under-minimum cases. Shows distributor by
        name, current liters, and how many more they need. This is what
        the user actually needs to act on — "NWS Michigan needs 6.00 L
        more" is concrete; "ADA breakdown is short" is not.
      */}
      {adaProgress.length > 0 ? (
        <>
          <div className="vr-heading">
            Distributors below 9 L minimum:
          </div>
          <ul className="banner-content-list">
            {adaProgress.map((ada) => (
              <li key={ada.name}>
                <strong>{ada.name}</strong>: {ada.liters.toFixed(2)} L / 9.00 L
                {" — needs "}
                <strong>{ada.shortBy.toFixed(2)} L</strong> more
              </li>
            ))}
          </ul>
        </>
      ) : null}
      {/*
        Generic MILO error strings from ada_breakdown.errors. Only render
        if we haven't already covered them with the more-structured blocks
        above. (The 9L minimum message is implicit in adaProgress, so we
        hide it when adaProgress is non-empty.)
      */}
      {milccErrorList.length > 0 && adaProgress.length === 0 ? (
        <>
          <div className="vr-heading">
            MLCC reported:
          </div>
          <ul className="banner-content-list">
            {milccErrorList.map((m, i) => (
              <li key={i}>{m}</li>
            ))}
          </ul>
        </>
      ) : null}
      {summary ? (
        <div className="vr-summary">
          <div className="vr-summary__row">
            <span className="muted">MLCC subtotal</span>
            <strong>{money(Number(summary.grossTotal ?? 0))}</strong>
          </div>
          <div className="vr-summary__row">
            <span className="muted">Net total</span>
            <strong>{money(Number(summary.netTotal ?? 0))}</strong>
          </div>
        </div>
      ) : null}
    </div>
  );
}

/**
 * Human failure card — one sentence headline, one-tap retry, quiet
 * technical detail for support (quality mandate 2026-06-12).
 */
function RunFailureCard({
  failureType,
  failureMessage,
  onRetryValidate,
  onOpenSettings,
}: {
  failureType: string | null;
  failureMessage: string | null;
  onRetryValidate: () => void;
  onOpenSettings: () => void;
}) {
  const { sentence, action } = humanizeRunFailure(failureType, failureMessage);

  return (
    <div className="drawer-run-failure" role="alert">
      <p className="drawer-run-failure__headline">{sentence}</p>
      <button
        type="button"
        className="btn primary btn-block"
        onClick={action === "check_credentials" ? onOpenSettings : onRetryValidate}
      >
        {action === "check_credentials" ? "Open Settings" : "Try again"}
      </button>
      <details className="drawer-run-failure__details">
        <summary>Technical detail</summary>
        <pre className="drawer-run-failure__detail-body">
          {failureType ?? "(none)"}
          {failureMessage ? `\n${failureMessage}` : ""}
        </pre>
      </details>
    </div>
  );
}
