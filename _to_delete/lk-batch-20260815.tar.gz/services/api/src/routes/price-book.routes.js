/**
 * Env tuning (UPC auto-match / picker):
 * - LK_CONFIDENT_MIN — minimum total score for confident single match (default 85)
 * - LK_CONFIDENT_LEAD — score lead over 2nd place required for confident when multiple rows (default 20)
 * - LK_PICKER_MIN — scores below this return low_confidence no-match (default 50)
 * - LK_PICKER_MAX — max ambiguous candidates returned (default 5)
 */
import crypto from "node:crypto";
import express from "express";
import supabase from "../config/supabase.js";
import { verifySupabaseAccessTokenAny } from "../lib/access-token.js";
import { lookupUpcFromOpenFoodFacts } from "../lib/open-food-facts.js";
import { extractBottleSizeMl, findMlccCandidatesForUpc, lookupUpcFromUpcitemdb } from "../lib/upcitemdb.js";
import { Sentry } from "../lib/sentry.js";
import {
  groupIntoFamilies,
  rankFamilies,
  priceBandFor,
  brandPrefixesFor,
  escapeIlike,
} from "../lib/related-products.js";
import {
  deleteUpcMapping,
  flagUpcMappingAsIncorrect,
  getUpcMapping,
  incrementUpcMappingScanCount,
  upsertUpcMapping,
} from "../lib/upc-mappings.js";
import { flagUpcMatchAsIncorrect, queueUpcMatchAudit } from "../mlcc/mlcc-upc-audit.js";
import { mlccCategoryMatchesAnyHint } from "../mlcc/mlcc-category-ontology.js";
import {
  extractCategoryHintsUpc,
  extractProofFromTitle,
  extractSizeFromTitle,
  scoreUpcToMlccCandidate,
} from "../mlcc/mlcc-upc-scoring.js";
import { BRAND_ALIAS_MAP, resolveSearchAliases } from "../mlcc/mlcc-brand-aliases.js";
import {
  familyNameSearchPrefix,
  filterToFamily,
  isMlccComboName,
  isMlccSpecialEditionName,
  normalizeMlccNameBaseForFamily,
  sanitizeIlikeForFamily,
} from "../mlcc/mlcc-product-family.js";
import { getLatestPriceBookRun, ingestMlccPriceBook } from "../mlcc/mlcc-price-book-ingestor.js";
import {
  escapeLikePattern,
  pickComboPrefixFallbackKey,
  familyMembersFromRows,
  familyHasMixedContainers,
  groupRowsIntoFamilies,
  COMBO_PREFIX_FALLBACK_MIN_LEN,
} from "../mlcc/family-tree-query.js";
import { runUpcEnrichment } from "../mlcc/mlcc-price-book-upc-enrichment.js";
import {
  checkAndIngestIfPriceBookChanged,
  checkAndIngestBetweenBookLists,
  checkAndRunUpcEnrichmentIfTxtChanged,
} from "../mlcc/mlcc-price-book-scheduler.js";
import { normalizeUpc } from "../lib/upc-normalize.js";

/** When true, picker confirmations persist UPC onto `mlcc_items` (local cache for future scans). */
const ENABLE_PICKER_SELECTION_CACHE = false;

/** When true, confident UPCitemdb/OFF matches persist `mlcc_items.upc` for future scans. */
const ENABLE_CONFIDENT_CACHE = process.env.ENABLE_CONFIDENT_CACHE !== "0";

const CONFIDENCE_THRESHOLDS = {
  auto_confident_min: Number(process.env.LK_CONFIDENT_MIN ?? 85),
  auto_confident_lead: Number(process.env.LK_CONFIDENT_LEAD ?? 20),
  picker_min: Number(process.env.LK_PICKER_MIN ?? 50),
  picker_max_candidates: Number(process.env.LK_PICKER_MAX ?? 5),
};
console.log("[price-book] confidence thresholds:", CONFIDENCE_THRESHOLDS);

const router = express.Router();

function requireServiceRole(req, res) {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key) {
    res.status(500).json({ ok: false, error: "Server misconfiguration" });
    return false;
  }
  const auth = req.headers.authorization?.trim();
  const expected = `Bearer ${key}`;
  if (auth !== expected) {
    res.status(401).json({ ok: false, error: "Unauthorized" });
    return false;
  }
  return true;
}

/**
 * Auth for the cron-triggered auto-update endpoint. Uses a DEDICATED
 * secret (LK_CRON_SECRET) — never the Supabase service-role key — because
 * this token lives in a third-party cron service's config. Accepts the
 * token via `X-Cron-Token` header (preferred) or `?token=` query param.
 */
function requireCronSecret(req, res) {
  const secret = process.env.LK_CRON_SECRET;
  if (!secret) {
    res.status(500).json({ ok: false, error: "LK_CRON_SECRET not configured" });
    return false;
  }
  const headerToken =
    typeof req.headers["x-cron-token"] === "string"
      ? req.headers["x-cron-token"].trim()
      : "";
  const queryToken =
    typeof req.query.token === "string" ? req.query.token.trim() : "";
  const provided = headerToken || queryToken;
  if (!provided || provided !== secret) {
    res.status(401).json({ ok: false, error: "Unauthorized" });
    return false;
  }
  return true;
}

function timingSafeEqualStrings(a, b) {
  if (typeof a !== "string" || typeof b !== "string") return false;
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

/**
 * Auth for catalog-truth WRITE endpoints (confirm / flag / report-no-match).
 *
 * FULL-SYSTEM-AUDIT finding #14 (P0, 2026-06-12): these endpoints were
 * completely unauthenticated. UPC mappings are GLOBAL — one row drives
 * what bottle opens on a scan for EVERY store — and /confirm wrote with
 * confidenceSource "user_confirmed", the trust level the resolution path
 * treats as gospel (it's exempt from the combo/edition safety swap).
 * Anyone who found the URL could remap any barcode to any product for
 * every customer, or mass-flag good mappings. Catalog truth is the moat;
 * its write surface must never be anonymous.
 *
 * Accepts (returns an actor object, or null after sending 401):
 *   a. service-role bearer (ops scripts) — timing-safe compare
 *   b. any signed-in user's Supabase access token (the scanner flow) —
 *      local JWKS verify with getUser() fallback, mirroring
 *      resolve-store.middleware.js
 */
async function requireUserOrServiceRole(req, res) {
  const auth = req.headers.authorization?.trim() ?? "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";
  if (!token) {
    res.status(401).json({ ok: false, error: "auth_required" });
    return null;
  }
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (serviceKey && timingSafeEqualStrings(token, serviceKey)) {
    return { kind: "service", userId: null };
  }
  const verified = await verifySupabaseAccessTokenAny(token);
  if (verified?.userId) {
    return { kind: "user", userId: verified.userId };
  }
  try {
    const { data: userData } = await supabase.auth.getUser(token);
    const uid = userData?.user?.id;
    if (uid) return { kind: "user", userId: uid };
  } catch {
    /* fall through to 401 */
  }
  res.status(401).json({ ok: false, error: "auth_required" });
  return null;
}

router.get("/status", async (req, res) => {
  try {
    const latestRun = await getLatestPriceBookRun(supabase);
    /*
      BASELINE FIX (2026-07-14, found by Tony's own eyes on device): this
      endpoint used to derive "the latest price book" from
      MAX(mlcc_items.last_price_book_date). The 7/13 New Item Price List
      ingest stamped its 304 rows with 2026-07-05 — which silently moved
      the freshness baseline for the ENTIRE catalog from the May full
      book to July 5, and every other bottle (Tito's included) turned
      red: "hasn't appeared in 62 days — likely discontinued." The
      catalog lying loudly, two days before order day.

      The truthful baseline is the latest FULL book — and
      getLatestPriceBookRun already returns exactly that (kind='full'
      filtered since 20260713013000). Item-max survives only as the
      fallback for a DB with no completed full run (fresh installs),
      where it equals the old behavior.
    */
    let rawDate = latestRun?.price_book_date ?? null;
    if (rawDate == null || String(rawDate).trim() === "") {
      const { data: newest, error: dErr } = await supabase
        .from("mlcc_items")
        .select("last_price_book_date")
        .not("last_price_book_date", "is", null)
        .order("last_price_book_date", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (dErr) {
        return res.status(500).json({ ok: false, error: dErr.message });
      }
      rawDate = newest?.last_price_book_date ?? null;
    }

    let priceBookDate = null;
    let daysSinceUpdate = null;
    /** @type {"fresh"|"aging"|"stale"} */
    let status = "stale";
    if (rawDate != null && String(rawDate).trim() !== "") {
      priceBookDate = String(rawDate);
      const d0 = new Date(`${priceBookDate}T12:00:00.000Z`);
      const now = new Date();
      daysSinceUpdate = Math.max(0, Math.floor((now.getTime() - d0.getTime()) / 86400000));
      if (daysSinceUpdate < 7) status = "fresh";
      else if (daysSinceUpdate <= 14) status = "aging";
      else status = "stale";
    }

    res.json({
      ok: true,
      latestRun,
      priceBookDate,
      daysSinceUpdate,
      status,
    });
  } catch (e) {
    res.status(500).json({
      ok: false,
      error: e instanceof Error ? e.message : String(e),
    });
  }
});

router.post("/ingest", async (req, res) => {
  if (!requireServiceRole(req, res)) return;
  try {
    const body = req.body && typeof req.body === "object" ? req.body : {};
    const url = typeof body.url === "string" ? body.url : undefined;
    const txtUrl = typeof body.txtUrl === "string" ? body.txtUrl : undefined;
    const dryRun = Boolean(body.dryRun);
    const skipUpcEnrichment = Boolean(body.skipUpcEnrichment);
    const result = await ingestMlccPriceBook(supabase, { url, dryRun });
    if (!result.ok) {
      return res.json({ ok: false, error: result.error || "Ingest failed" });
    }
    // After the xlsx catalog upsert, enrich mlcc_items.upc from the TXT
    // version of the same price book (TXT has a GTIN/UPC column xlsx doesn't).
    // Failing this step does NOT fail the overall ingest — catalog data is
    // already in place; UPCs are an enrichment.
    let upcEnrichment = null;
    if (!skipUpcEnrichment && !dryRun) {
      try {
        upcEnrichment = await runUpcEnrichment(supabase, { urlOverride: txtUrl });
      } catch (e) {
        upcEnrichment = {
          ok: false,
          error: e instanceof Error ? e.message : String(e),
        };
      }
    }
    res.json({ ok: true, result, upcEnrichment });
  } catch (e) {
    res.status(500).json({
      ok: false,
      error: e instanceof Error ? e.message : String(e),
    });
  }
});

/**
 * Standalone UPC-only enrichment endpoint.
 * Use when you want to refresh mlcc_items.upc without re-ingesting catalog
 * data, or as a smoke test of the parse + write pipeline.
 *
 * Body: { txtUrl?: string, dryRun?: boolean }
 */
router.post("/enrich-upcs", async (req, res) => {
  if (!requireServiceRole(req, res)) return;
  try {
    const body = req.body && typeof req.body === "object" ? req.body : {};
    const txtUrl = typeof body.txtUrl === "string" ? body.txtUrl : undefined;
    const dryRun = Boolean(body.dryRun);
    const result = await runUpcEnrichment(supabase, { urlOverride: txtUrl, dryRun });
    if (!result.ok) {
      return res.json({ ok: false, ...result });
    }
    res.json(result);
  } catch (e) {
    res.status(500).json({
      ok: false,
      error: e instanceof Error ? e.message : String(e),
    });
  }
});

/**
 * Auto-update check — designed to be hit by an external cron service
 * (e.g. cron-job.org) once a day. Discovers the currently-published MLCC
 * price book and ingests it ONLY if it differs from our last ingest.
 * Idempotent and cheap when nothing changed (a single page fetch).
 *
 * Auth: X-Cron-Token header (or ?token= query) must equal LK_CRON_SECRET.
 * Body: { force?: boolean } — force=true re-ingests even if URL unchanged.
 */
router.post("/check-updates", async (req, res) => {
  if (!requireCronSecret(req, res)) return;
  try {
    const body = req.body && typeof req.body === "object" ? req.body : {};
    const force = Boolean(body.force);
    const result = await checkAndIngestIfPriceBookChanged(supabase, { force });
    /*
      Between-book lists (2026-08-04): same daily tick, AFTER the full
      check — new-item / retail-price-changes / ada-changes lists ingest
      additively the day MLCC publishes them instead of waiting for the
      next full book. Fail-soft: a between-book hiccup never turns the
      cron response into an error (the full-book result is the headline).
    */
    const betweenBook = await checkAndIngestBetweenBookLists(supabase);
    /*
      TXT watch (2026-08-05, barcode auto-currency mandate): MLCC posts
      the UPC-bearing TXT on its own schedule (Aug book was live for
      days before its TXT). Re-enrich the moment the TXT URL changes —
      ledgered under kind='upc_txt', idempotent, fail-soft.
    */
    const upcTxt =
      result.ingested === true
        ? { checked: false, ran: false, reason: "full ingest already ran enrichment this tick" }
        : await checkAndRunUpcEnrichmentIfTxtChanged(supabase);
    res.json({ ok: true, ...result, between_book: betweenBook.results, upc_txt: upcTxt });
  } catch (e) {
    res.status(500).json({
      ok: false,
      error: e instanceof Error ? e.message : String(e),
    });
  }
});

function applyMlccItemsFilters(q, adaNumber, isNewItemQ) {
  let query = q;
  if (adaNumber) {
    query = query.eq("ada_number", adaNumber);
  }
  if (isNewItemQ === "true") {
    query = query.eq("is_new_item", true);
  } else if (isNewItemQ === "false") {
    query = query.eq("is_new_item", false);
  }
  return query;
}

/** Same semantics as `applyMlccItemsFilters` for in-memory rows (e.g. RPC results). */
function filterMlccRowsClientSide(rows, adaNumber, isNewItemQ) {
  return (rows ?? []).filter((row) => {
    if (adaNumber && String(row.ada_number ?? "").trim() !== adaNumber) return false;
    if (isNewItemQ === "true" && row.is_new_item !== true) return false;
    if (isNewItemQ === "false" && row.is_new_item !== false) return false;
    return true;
  });
}

/**
 * Stop words to drop from search queries. Without this, typing "stolichnaya
 * vanilla 750 ml fifth" includes "750", "ml", "fifth" as match tokens, and
 * "stolichnaya vanilla vodka" requires "vodka" to be in the MLCC name (which
 * it usually isn't — MLCC stores names like "STOLICHNAYA VANIL" without the
 * type word). Stop words are dropped before AND-token search, so they neither
 * narrow nor pollute results.
 */
const SEARCH_STOP_WORDS = new Set([
  // Bottle size unit / abbreviation
  "ml", "l", "oz",
  // Bottle size words / slang
  "fifth", "pint", "quart", "liter", "litre", "gallon", "handle",
  "halfpint", "halfgallon", "halfliter", "mini",
  // Bottle qualifiers
  "bottle", "bottles", "case", "pack", "single",
  // Articles / fillers
  "a", "an", "the", "of", "and", "with",
  // Plastic / packaging shorthand
  "pl", "plastic",
  // Liquor TYPE words — present in user search but NOT always in MLCC names
  // (e.g. "STOLICHNAYA VANIL" has no "VODKA" in name). Without this rule,
  // typing "stoli vanilla vodka" requires "vodka" in name → 0 matches → falls
  // to fuzzy → random vanillas. Drop them as stop words so the brand+flavor
  // tokens carry the search.
  "vodka", "rum", "gin", "tequila", "whiskey", "whisky", "rye",
  "scotch", "bourbon", "cognac", "brandy", "liqueur",
  "schnapps", "mezcal", "cordial", "spirit", "spirits",
]);

/**
 * Tokenize search query and drop stop words / pure-numeric noise (sizes like
 * "750"). Keeps short numeric tokens that are likely codes (3+ digits stay as
 * potential code tokens) and any alphanumeric that's a valid match token.
 *
 * Examples:
 *   "stolichnaya vanilla 750 ml fifth"  →  ["stolichnaya", "vanilla"]
 *   "smirnoff 80 200 ml"                 →  ["smirnoff", "80"]
 *   "tito"                                →  ["tito"]
 *   "9247"                                →  ["9247"]
 */
function extractSearchTokens(rawQuery) {
  const normalized = normalizeSearchTerm(rawQuery);
  if (!normalized) return [];
  return normalized
    .split(/\s+/)
    .map((t) => t.trim())
    .filter((t) => t.length > 0)
    .filter((t) => !SEARCH_STOP_WORDS.has(t))
    // drop pure-numeric tokens that look like sizes (200/375/750/1000/1750)
    // but keep proof numbers (80, 100, 90.4) and 4+ digit codes (9247, 14888)
    .filter((t) => {
      if (!/^\d+(\.\d+)?$/.test(t)) return true; // not numeric — keep
      const n = Number(t);
      // Drop common bottle sizes that travel with names
      if ([50, 100, 200, 375, 700, 750, 1000, 1750].includes(n)) return false;
      return true;
    });
}

/**
 * Expand a single search token into all variants that should match against
 * MLCC's catalog. Returns an array of substring patterns (already escaped
 * for ilike).
 *
 * Three sources of expansion:
 *   1. The token itself (always)
 *   2. Brand alias map (e.g. stoli → stolichnaya, vanilla → vanil/vanilia)
 *   3. Auto-prefix shortening for tokens 6+ chars long: also include the
 *      first N-1 and N-2 characters as a prefix substring. This catches
 *      MLCC truncations we haven't manually aliased yet (e.g. some new
 *      flavor word abbreviates to first-5-chars).
 *
 * The auto-prefix layer means we don't need to enumerate every possible
 * MLCC truncation by hand — any token long enough naturally tries shorter
 * forms.
 */
function expandTokenForSearch(token) {
  const variants = new Set();
  const safeBase = escapeIlikeOrToken(token);
  if (!safeBase) return [];
  variants.add(safeBase);

  // Layer 1 — explicit aliases from BRAND_ALIAS_MAP
  for (const aliasV of resolveSearchAliases(token)) {
    const safe = escapeIlikeOrToken(aliasV);
    if (safe) variants.add(safe);
  }

  // Layer 2 — auto-prefix shortening for tokens 6+ chars
  // "vanilla" (7) → also try "vanill" (6) and "vanil" (5)
  // "stolichnaya" (11) → also try "stolichnay" (10) and "stolichna" (9)
  // Stops at length 4 to avoid over-matching short tokens.
  if (token.length >= 6) {
    for (const cut of [1, 2]) {
      const prefix = token.slice(0, token.length - cut);
      if (prefix.length >= 4) {
        const safe = escapeIlikeOrToken(prefix);
        if (safe) variants.add(safe);
      }
    }
  }

  return Array.from(variants);
}

/**
 * Build an AND-across-tokens query for mlcc_items. Every search token must
 * appear (in name OR name_normalized) considering aliases AND auto-prefix
 * truncations. This replaces the previous single-substring OR search which
 * couldn't narrow multi-word queries.
 *
 * For each token we build an OR group of:
 *   - name ilike each variant
 *   - name_normalized ilike each variant
 *   - code ilike the original token (for code-style search)
 * Multiple .or() calls on the same query builder are AND'd at top level by
 * Supabase / PostgREST.
 */
function applyTokenAndSearchToQuery(q, search) {
  const tokens = extractSearchTokens(search);
  if (tokens.length === 0) {
    // No significant tokens — fall back to substring on the raw search
    const original = escapeIlikeOrToken(search);
    const spaceFree = original.replace(/\s+/g, "");
    return q.or(
      `name.ilike.%${original}%,name_normalized.ilike.%${original}%,name_searchable.ilike.%${spaceFree}%,code.ilike.%${original}%`,
    );
  }

  for (const token of tokens) {
    const variants = expandTokenForSearch(token);
    if (variants.length === 0) continue;
    const orParts = [];
    for (const v of variants) {
      orParts.push(`name.ilike.%${v}%`);
      orParts.push(`name_normalized.ilike.%${v}%`);
      // name_searchable strips spaces too, so a combined-word query token
      // (e.g. "rumchata") matches a spaced catalog name and vice-versa.
      // Purely additive — never removes a match that name_normalized makes.
      // (MLCC name-weirdness fix, 2026-06-09.)
      orParts.push(`name_searchable.ilike.%${v}%`);
    }
    // Also let the original token match `code` directly (numeric code search)
    orParts.push(`code.ilike.%${escapeIlikeOrToken(token)}%`);
    q = q.or(orParts.join(","));
  }
  return q;
}

/**
 * @deprecated Kept for compatibility with any caller still using the
 * single-substring OR search. New code should use `applyTokenAndSearchToQuery`.
 */
function applyItemsOrSearchToQuery(q, search) {
  return applyTokenAndSearchToQuery(q, search);
}

/** Escape %, _, \\ for ilike patterns; strip commas so .or() filter stays valid. */
function escapeIlikeOrToken(s) {
  return String(s)
    .replace(/\\/g, "\\\\")
    .replace(/%/g, "\\%")
    .replace(/_/g, "\\_")
    .replace(/,/g, "");
}

/**
 * Lowercase, strip punctuation (non-alphanumeric except spaces), collapse spaces, trim.
 * Matches DB name_normalized semantics for fuzzy search.
 */
function normalizeSearchTerm(str) {
  return String(str)
    .toLowerCase()
    .replace(/[^a-z0-9 ]/gi, "")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Flavor / line-extension / novelty-format words that mark a product as a
 * VARIANT of a brand's flagship expression rather than the flagship itself.
 *
 * Tony, 2026-06-13: searching "jack daniels" was returning "JACK DANIELS
 * APPLE" first — purely because A < O alphabetically and every JD SKU has
 * scan_count 0 pre-launch (orderMlccItemsByScanThenName falls through to
 * name asc). A real customer typing the bare brand name wants the classic
 * bottle (Old No. 7 / Black Label), not a flavored line extension.
 *
 * This is a HEURISTIC COLD-START TIEBREAKER ONLY — see sortByRelevance:
 *  1. scan_count desc always wins first (real usage data beats the heuristic
 *     the moment any SKU in the family gets scanned/picked).
 *  2. A query that itself names a flavor (e.g. "jack daniels honey") isn't
 *     penalized for that word — only EXTRA flavor words not in the query
 *     count against a row.
 *  3. Worst case for an edge-case brand where the flagship name happens to
 *     contain one of these words (e.g. a "spiced rum" as a brand's base
 *     product): it just falls back to the previous alphabetical behavior,
 *     which self-corrects once scan_count accrues.
 */
const VARIANT_KEYWORDS = new Set([
  // Fruit / flavor words common across vodka, whiskey, rum, tequila, gin
  "honey", "fire", "apple", "citrus", "peach", "cherry", "watermelon",
  "cinnamon", "coconut", "lime", "lemon", "lemonade", "raspberry",
  "blackberry", "strawberry", "berry", "grape", "mango", "pineapple",
  "orange", "banana", "vanilla", "vanil", "caramel", "butterscotch",
  "chocolate", "espresso", "coffee", "cream", "punch", "tropical",
  "ginger", "spiced", "spice", "melon", "passion", "grapefruit", "pear",
  "plum", "almond", "hazelnut", "mint", "rootbeer", "cola", "pumpkin",
  "maple", "tupelo", "fizz", "sugarfree",
  // Limited-edition / novelty-format markers — not the default bottle
  "chocolates", "accessible", "mclaren", "edition", "anniversary",
  "downhome", "blackjack", "lynchburg",
]);

/**
 * Count VARIANT_KEYWORDS hits in `name` that are NOT already present in
 * `queryTokenSet` (so searching "jack daniels honey" doesn't penalize the
 * Honey SKU for matching what the user asked for).
 */
function computeVariantPenalty(name, queryTokenSet) {
  const tokens = normalizeSearchTerm(name).split(/\s+/).filter(Boolean);
  let penalty = 0;
  for (const t of tokens) {
    if (VARIANT_KEYWORDS.has(t) && !queryTokenSet.has(t)) penalty += 1;
  }
  return penalty;
}

/**
 * Search-result ordering: real usage (scan_count) first, then the
 * flagship-vs-variant heuristic (computeVariantPenalty), then name, then
 * code. Shared by the AND-of-tokens path, the fuzzy RPC path, and the
 * Levenshtein fallback so a brand search like "jack daniels" surfaces the
 * classic bottle first everywhere, not just in one code path.
 */
function sortByRelevance(rows, queryTokenSet) {
  return [...(rows ?? [])].sort((a, b) => {
    const sa = Number(a.scan_count) || 0;
    const sb = Number(b.scan_count) || 0;
    if (sa !== sb) return sb - sa;
    const pa = computeVariantPenalty(String(a.name ?? ""), queryTokenSet);
    const pb = computeVariantPenalty(String(b.name ?? ""), queryTokenSet);
    if (pa !== pb) return pa - pb;
    const na = String(a.name ?? "");
    const nb = String(b.name ?? "");
    if (na !== nb) return na.localeCompare(nb);
    return String(a.code ?? "").localeCompare(String(b.code ?? ""), undefined, { numeric: true });
  });
}

/** Strip % and _ from external strings used inside ilike patterns (defense in depth). */
function sanitizeIlikeValue(s) {
  return String(s).replace(/%/g, "").replace(/_/g, "");
}

/** Longest `BRAND_ALIAS_MAP` key contained in `normalizedRaw` (substring match). */
function findLongestContainedBrandKey(normalizedRaw) {
  const term = String(normalizedRaw ?? "").trim();
  if (!term) return null;
  let best = null;
  let bestLen = -1;
  for (const key of BRAND_ALIAS_MAP.keys()) {
    if (!key || term.length < key.length) continue;
    if (!term.includes(key)) continue;
    if (key.length > bestLen) {
      bestLen = key.length;
      best = key;
    }
  }
  return best;
}

function removeFirstSubstring(haystack, needle) {
  const h = String(haystack ?? "");
  const n = String(needle ?? "");
  if (!n) return h.trim();
  const i = h.indexOf(n);
  if (i < 0) return h.replace(/\s+/g, " ").trim();
  return (h.slice(0, i) + h.slice(i + n.length)).replace(/\s+/g, " ").trim();
}

const MULTI_TERM_BRAND_FETCH_CAP = 500;

/**
 * One query per MLCC-style brand variant; each row must match brand phrase and every suffix word on name_normalized.
 * @returns {Promise<{ rows: object[], error: Error | null }>}
 */
async function multiTermBrandSearch({
  supabase,
  brandKey,
  normalizedRaw,
  adaNumber,
  isNewItemQ,
}) {
  const suffixRaw = removeFirstSubstring(normalizedRaw, brandKey);
  const suffixWords = suffixRaw
    ? suffixRaw
        .split(/\s+/)
        .map((w) => sanitizeIlikeValue(w))
        .filter(Boolean)
    : [];

  const variants = BRAND_ALIAS_MAP.get(brandKey) ?? [];
  const brandCandidates = [];
  const seenBrand = new Set();
  for (const b of [brandKey, ...variants]) {
    const t = sanitizeIlikeValue(b);
    if (!t || seenBrand.has(t)) continue;
    seenBrand.add(t);
    brandCandidates.push(t);
  }

  const rowsById = new Map();

  for (const brandPart of brandCandidates) {
    let q = supabase.from("mlcc_items").select("*");
    q = applyMlccItemsFilters(q, adaNumber, isNewItemQ);
    q = q.ilike("name_normalized", `%${brandPart}%`);
    for (const w of suffixWords) {
      q = q.ilike("name_normalized", `%${w}%`);
    }
    const { data, error } = await q
      .order("scan_count", { ascending: false })
      .order("name", { ascending: true })
      .limit(MULTI_TERM_BRAND_FETCH_CAP);
    if (error) return { rows: [], error };
    for (const row of data ?? []) {
      if (row?.id && !rowsById.has(row.id)) rowsById.set(row.id, row);
    }
  }

  const merged = [...rowsById.values()].sort((a, b) => {
    const sa = Number(a.scan_count) || 0;
    const sb = Number(b.scan_count) || 0;
    if (sa !== sb) return sb - sa;
    const na = String(a.name ?? "");
    const nb = String(b.name ?? "");
    if (na !== nb) return na.localeCompare(nb);
    return String(a.code ?? "").localeCompare(String(b.code ?? ""), undefined, { numeric: true });
  });
  return { rows: merged, error: null };
}

function queueUpcLookupLog(row) {
  try {
    void supabase
      .from("upc_lookups")
      .insert(row)
      .then(({ error }) => {
        if (error) console.log("[price-book-upc] upc_lookups log failed", error.message);
      });
  } catch (e) {
    const m = e instanceof Error ? e.message : String(e);
    console.log("[price-book-upc] upc_lookups log exception", m);
  }
}

/**
 * Fire-and-forget scan popularity bump for search ranking.
 * @param {import("@supabase/supabase-js").SupabaseClient} sb
 * @param {string | undefined} mlccId
 */
function incrementScanCount(sb, mlccId) {
  const id = mlccId != null ? String(mlccId).trim() : "";
  if (!id) return;
  void (async () => {
    try {
      const { data: cur, error: rErr } = await sb.from("mlcc_items").select("scan_count").eq("id", id).maybeSingle();
      if (rErr) throw rErr;
      const next = (Number(cur?.scan_count) || 0) + 1;
      const { error: uErr } = await sb
        .from("mlcc_items")
        .update({
          scan_count: next,
          last_scanned_at: new Date().toISOString(),
        })
        .eq("id", id);
      if (uErr) throw uErr;
      if (process.env.DEBUG_UPC_FILTER === "1") {
        console.log("[price-book][DEBUG_UPC_FILTER]", JSON.stringify({ scan_increment: true, id, next }));
      }
    } catch (e) {
      if (typeof Sentry?.captureException === "function") {
        Sentry.captureException(e);
      }
    }
  })();
}

/**
 * Category keywords inferred from UPCitemdb / OFF product name for MLCC candidate filtering.
 * @param {string} productName
 * @returns {string[]}
 */
function extractCategoryHints(productName) {
  return extractCategoryHintsUpc(productName);
}

/**
 * @param {object[]} candidates mlcc_items rows
 * @param {string[]} hints from extractCategoryHints
 */
function filterMlccCandidatesByCategory(candidates, hints) {
  if (!hints || hints.length === 0) return [...candidates];
  return candidates.filter((c) => mlccCategoryMatchesAnyHint(c?.category, hints));
}

/**
 * @param {{ candidates?: object[] }} mlcc
 * @param {string} productName
 * @returns {{ candidates: object[]; confidenceWarning?: string; unfiltered: object[] }}
 */
function applyCategoryHintsToCandidates(mlcc, productName) {
  const unfiltered = [...(mlcc.candidates ?? [])];
  const hints = extractCategoryHints(productName);
  const strictFiltered = filterMlccCandidatesByCategory(unfiltered, hints);

  /** @type {object[]} */
  let candidates;
  /** @type {string | undefined} */
  let confidenceWarning;

  if (hints.length === 0) {
    candidates = unfiltered;
  } else if (strictFiltered.length > 0) {
    candidates = strictFiltered;
  } else if (unfiltered.length > 0) {
    candidates = [];
    confidenceWarning = "strict_filter_no_matches";
  } else {
    candidates = [];
  }

  if (process.env.DEBUG_UPC_FILTER === "1") {
    const path =
      hints.length === 0
        ? "hints_empty_pass_through"
        : strictFiltered.length > 0
          ? "hints_strict_ok"
          : unfiltered.length > 0
            ? "hints_strict_empty"
            : "unfiltered_empty";
    console.log(
      "[price-book-upc][DEBUG_UPC_FILTER]",
      JSON.stringify({
        productName,
        unfilteredCount: unfiltered.length,
        unfiltered: unfiltered.map((c) => ({
          code: c?.code ?? null,
          name: c?.name ?? null,
          category: c?.category ?? null,
        })),
        hints,
        strictFilteredCount: strictFiltered.length,
        finalCandidateCount: candidates.length,
        confidenceWarning: confidenceWarning ?? null,
        path,
      }),
    );
  }

  return { candidates, confidenceWarning, unfiltered };
}

/**
 * Collapse immediate repeated n-grams (3-, 2-, then 1-word), e.g. "A B A B C" → "A B C".
 * @param {string[]} words
 * @returns {string[]}
 */
function collapseRepeatedPhrases(words) {
  let w = [...words];
  for (let pass = 0; pass < 5; pass++) {
    let changed = false;
    outer: for (let n = 3; n >= 1; n--) {
      for (let i = 0; i + 2 * n <= w.length; i++) {
        const a = w.slice(i, i + n).join(" ").toLowerCase();
        const b = w.slice(i + n, i + 2 * n).join(" ").toLowerCase();
        if (a === b) {
          w.splice(i + n, n);
          changed = true;
          break outer;
        }
      }
    }
    if (!changed) break;
  }
  return w;
}

/**
 * Dedupe repeated phrases and words, strip size/proof/bottle noise for search auto-fill.
 * @param {string} name
 * @returns {string}
 */
function cleanProductNameForSearch(name) {
  const raw = String(name ?? "").trim();
  let words = raw.split(/\s+/).filter(Boolean);
  words = collapseRepeatedPhrases(words);
  const out = [];
  for (const token of words) {
    const lw = token.toLowerCase();
    if (out.length && out[out.length - 1].toLowerCase() === lw) continue;
    out.push(token);
  }
  let s = out.join(" ");
  s = s.replace(/,\s*\d+(?:\.\d+)?\s*m\s*l\b/gi, "");
  s = s.replace(/,\s*\d+(?:\.\d+)?\s*l\b/gi, "");
  s = s.replace(/\(\s*\d+(?:\.\d+)?\s*%\s*abv\s*\)/gi, "");
  s = s.replace(/\(\s*\d+(?:\.\d+)?\s*proof\s*\)/gi, "");
  s = s.replace(/\b\d+(?:\.\d+)?\s*proof\b/gi, "");
  s = s.replace(/\b\d+(?:\.\d+)?\s*m\s*l\b/gi, "");
  s = s.replace(/\b\d+(?:\.\d+)?\s*l\b/gi, "");
  s = s.replace(/\s+Bottle\b/gi, " ");
  s = s.replace(/\bBottle\b$/i, "");
  s = s.replace(/\s+/g, " ").replace(/^[, ]+|[, ]+$/g, "").trim();
  return s;
}

function buildUpcData(upcItem) {
  const rawTitle = String(upcItem?.name ?? "").trim();
  const rawSize = String(upcItem?.rawSize ?? "").trim();
  const offersText = String(upcItem?.offersText ?? "").trim();
  const sizeResolution = extractSizeFromTitle({ rawTitle, rawSize, offersText });
  const size_ml = sizeResolution.preferredSize ?? extractBottleSizeMl(rawTitle);
  const plausible_sizes = Array.isArray(sizeResolution.plausibleSizes)
    ? sizeResolution.plausibleSizes
    : size_ml != null
      ? [size_ml]
      : [];
  const imageUrl =
    typeof upcItem?.imageUrl === "string" && upcItem.imageUrl.trim() ? upcItem.imageUrl.trim() : null;
  return {
    name: rawTitle,
    brand: String(upcItem?.brand ?? "").trim(),
    size_ml,
    plausible_sizes,
    sizePenalty: sizeResolution.penalty,
    proof: extractProofFromTitle(rawTitle),
    rawTitle,
    rawSize,
    offersText,
    imageUrl,
  };
}

/**
 * @param {ReturnType<typeof buildUpcData>} upcData
 * @param {object[]} pool
 * @param {Set<unknown>} strictCategoryPassIdSet
 * @param {boolean} hintsEmpty
 */
function scoreMlccPoolForUpc(upcData, pool, strictCategoryPassIdSet, hintsEmpty) {
  const scored = [];
  for (const row of pool) {
    const r = scoreUpcToMlccCandidate(upcData, row);
    scored.push({ row, ...r });
  }
  const allCandidateScores = scored.map((s) => ({
    code: String(s.row.code ?? ""),
    name: String(s.row.name ?? ""),
    score: s.total,
    disqualified: s.disqualified,
    reasons: s.reasons,
  }));

  const eligible = scored.filter(
    (s) => !s.disqualified && (hintsEmpty || strictCategoryPassIdSet.has(s.row.id)),
  );
  eligible.sort(
    (a, b) => b.total - a.total || String(a.row.code ?? "").localeCompare(String(b.row.code ?? "")),
  );
  return { scored, allCandidateScores, eligible };
}

/**
 * @param {Array<{ total: number; row: object; breakdown: object }>} sortedEligible
 * @param {typeof CONFIDENCE_THRESHOLDS} th
 */
function decideUpcMatchFromScores(sortedEligible, th) {
  if (!sortedEligible.length) return { mode: "none" };
  const top = sortedEligible[0];
  const second = sortedEligible[1];
  const pickerMin = th.picker_min;
  const confidentMin = th.auto_confident_min;
  const lead = th.auto_confident_lead;
  const maxAmb = th.picker_max_candidates;

  if (top.total < pickerMin) return { mode: "low_confidence", top };
  const single = sortedEligible.length === 1;
  const gap = second ? top.total - second.total : Infinity;
  if (top.total >= confidentMin && single) {
    const nameStrong = Number(top.breakdown?.nameSimilarityScore ?? 0) >= 7;
    const brandExact = String(top.breakdown?.brandSource ?? "") === "exact";
    const markerConflict = Boolean(top.breakdown?.markerConflict);
    if (nameStrong || (brandExact && !markerConflict)) return { mode: "confident", winner: top };
    return {
      mode: "ambiguous",
      topFive: [top],
      confidenceWarning: "single_candidate_requires_confirmation",
    };
  }
  if (top.total >= confidentMin && gap >= lead) return { mode: "confident", winner: top };
  if (
    (top.total >= pickerMin && top.total < confidentMin) ||
    (second != null && gap < lead)
  ) {
    return { mode: "ambiguous", topFive: sortedEligible.slice(0, maxAmb) };
  }
  return { mode: "confident", winner: top };
}

/**
 * @param {import("express").Response} res
 * @param {{ upc: string; upcItem: object; rawApiResponse: unknown; source: "upcitemdb" | "open_food_facts" }} ctx
 */
async function respondWithScoredUpcMatch(res, { upc, upcItem, rawApiResponse, source }) {
  const upcData = buildUpcData(upcItem);
  const mlcc = await findMlccCandidatesForUpc(
    supabase,
    { ...upcItem, size_ml: upcData.size_ml, plausible_sizes: upcData.plausible_sizes },
    { candidateLimit: 50 },
  );
  const { candidates: categoryPassRows, confidenceWarning, unfiltered } = applyCategoryHintsToCandidates(
    mlcc,
    upcItem.name,
  );
  const hintsEmpty = extractCategoryHints(upcItem.name).length === 0;
  const strictSet = new Set((categoryPassRows ?? []).map((r) => r.id));
  const cleanedName = cleanProductNameForSearch(upcData.rawTitle);
  const { allCandidateScores, eligible } = scoreMlccPoolForUpc(upcData, unfiltered, strictSet, hintsEmpty);

  const noMatchExtraWarning =
    confidenceWarning ??
    (!eligible.length && unfiltered.length > 0 ? "all_candidates_disqualified" : null);

  const topForBreakdown = eligible[0];
  const topScore = topForBreakdown ? topForBreakdown.total : 0;
  const topBreakdown = topForBreakdown ? topForBreakdown.breakdown : null;

  const decision = decideUpcMatchFromScores(eligible, CONFIDENCE_THRESHOLDS);
  const decisionConfidenceWarning = decision.confidenceWarning ?? null;

  if (process.env.DEBUG_UPC_FILTER === "1") {
    console.log(
      "[price-book-upc][DEBUG_UPC_FILTER]",
      JSON.stringify({
        phase: "decision",
        upc,
        source,
        decisionMode: decision.mode,
        eligibleCount: eligible.length,
        poolCount: unfiltered.length,
        confidenceWarning: confidenceWarning ?? decisionConfidenceWarning,
        noMatchExtraWarning,
        topScore,
      }),
    );
  }

  const auditBase = {
    upc,
    upcBrand: upcData.brand || null,
    upcProductName: cleanedName,
    upcProductNameRaw: upcData.rawTitle,
    allCandidateScores,
  };

  if (decision.mode === "confident" && decision.winner) {
    const match = decision.winner.row;
    const winnerBreakdown = decision.winner.breakdown ?? {};
    const cacheQuality =
      decision.winner.total >= 90 &&
      Number(winnerBreakdown.nameSimilarityScore ?? 0) >= 5 &&
      Number(winnerBreakdown.sizeScore ?? 0) === 20 &&
      !Boolean(winnerBreakdown.markerConflict)
        ? "high"
        : "provisional";

    let cached = false;
    if (ENABLE_CONFIDENT_CACHE && cacheQuality === "high") {
      const { error: upErr } = await supabase.from("mlcc_items").update({ upc }).eq("id", match.id);
      if (upErr) {
        console.log("[price-book-upc] mlcc_items upc cache update failed", upErr.message);
      } else {
        cached = true;
        void upsertUpcMapping(supabase, {
          upc,
          mlccCode: String(match.code ?? ""),
          confidenceSource: "auto_high_score",
          confirmedBy: null,
        });
      }
    } else if (process.env.DEBUG_UPC_FILTER === "1") {
      console.log(
        "[price-book-upc][DEBUG_UPC_FILTER]",
        JSON.stringify({
          phase: "cache_skip",
          upc,
          mlccCode: String(match.code ?? ""),
          cacheQuality,
          confidenceScore: decision.winner.total,
          breakdown: winnerBreakdown,
        }),
      );
    }
    const { data: refreshed } = await supabase.from("mlcc_items").select("*").eq("id", match.id).maybeSingle();
    const base = refreshed ?? { ...match };
    const product = { ...base, imageUrl: upcData.imageUrl ?? null };
    incrementScanCount(supabase, product.id);
    queueUpcLookupLog({
      upc,
      matched_mlcc_code: product.code ?? null,
      matched_product_name: product.name ?? null,
      source,
      raw_api_response: rawApiResponse ?? null,
    });
    console.log("[price-book-upc] matched via", source, "(confident)", product.id);

    queueUpcMatchAudit(supabase, {
      ...auditBase,
      matchedMlccCode: product.code != null ? String(product.code) : null,
      matchMode: "confident",
      confidenceScore: decision.winner.total,
      confidenceWarning: confidenceWarning ?? decisionConfidenceWarning,
      scoringBreakdown: decision.winner.breakdown,
      cached,
    });

    return res.json({
      ok: true,
      product,
      matchMode: "confident",
      confidenceScore: decision.winner.total,
      scoringBreakdown: decision.winner.breakdown,
      allCandidateScores,
      cacheQuality,
      upcProductName: upcItem.name,
      upcBrand: upcItem.brand,
      ...(confidenceWarning || decisionConfidenceWarning
        ? { confidenceWarning: confidenceWarning ?? decisionConfidenceWarning }
        : {}),
    });
  }

  if (decision.mode === "ambiguous" && decision.topFive?.length) {
    const img = upcData.imageUrl ?? null;
    const rows = decision.topFive.map((s) => ({ ...s.row, imageUrl: img }));
    queueUpcLookupLog({
      upc,
      matched_mlcc_code: null,
      matched_product_name: null,
      source,
      raw_api_response: rawApiResponse ?? null,
    });

    queueUpcMatchAudit(supabase, {
      ...auditBase,
      matchedMlccCode: null,
      matchMode: "ambiguous",
      confidenceScore: decision.topFive[0].total,
      confidenceWarning: confidenceWarning ?? decisionConfidenceWarning,
      scoringBreakdown: decision.topFive[0].breakdown,
      cached: false,
    });

    return res.json({
      ok: true,
      needsUserConfirmation: true,
      matchMode: "ambiguous",
      candidates: rows,
      upcProductName: upcItem.name,
      upcBrand: upcItem.brand,
      message: "Multiple products match. User must select.",
      confidenceScore: decision.topFive[0].total,
      scoringBreakdown: decision.topFive[0].breakdown,
      allCandidateScores,
      ...(confidenceWarning || decisionConfidenceWarning
        ? { confidenceWarning: confidenceWarning ?? decisionConfidenceWarning }
        : {}),
    });
  }

  let finalWarning = noMatchExtraWarning;
  if (decision.mode === "low_confidence") finalWarning = "low_confidence_match";

  queueUpcLookupLog({
    upc,
    matched_mlcc_code: null,
    matched_product_name: null,
    source,
    raw_api_response: rawApiResponse ?? null,
  });

  queueUpcMatchAudit(supabase, {
    ...auditBase,
    matchedMlccCode: null,
    matchMode: "no_match",
    confidenceScore: topScore,
    confidenceWarning: finalWarning,
    scoringBreakdown: topBreakdown,
    cached: false,
  });

  const noMatchBody = {
    ok: false,
    error: "upc_found_but_no_mlcc_match",
    productName: cleanedName,
    upcProductNameRaw: upcData.rawTitle,
    upcProductName: upcItem.name,
    upcBrand: upcItem.brand,
    hint: "search_by_name",
    confidenceScore: topScore,
    scoringBreakdown: topBreakdown,
    allCandidateScores,
  };
  if (finalWarning) noMatchBody.confidenceWarning = finalWarning;
  return res.json(noMatchBody);
}

export async function priceBookUpcFlagHandler(req, res) {
  try {
    const actor = await requireUserOrServiceRole(req, res);
    if (!actor) return;
    const upc = String(req.params.upc ?? "").trim();
    if (!upc) {
      return res.status(400).json({ ok: false, error: "upc_required" });
    }
    const body = req.body && typeof req.body === "object" ? req.body : {};
    const reason =
      typeof body.reason === "string" && body.reason.trim() ? body.reason.trim() : "user_says_wrong";
    if (process.env.DEBUG_UPC_FILTER === "1") {
      console.log("[price-book-upc][DEBUG_UPC_FILTER]", JSON.stringify({ flag_request: true, upc, reason }));
    }
    const r = await flagUpcMatchAsIncorrect(supabase, upc, reason);
    if (!r.ok) {
      return res.status(500).json({ ok: false, error: r.error ?? "flag_failed" });
    }
    const mappingFlag = await flagUpcMappingAsIncorrect(supabase, upc);
    const clearedMap = await deleteUpcMapping(supabase, upc);
    return res.status(200).json({
      ok: true,
      message: "Match flagged; next scan will re-match from scratch.",
      clearedMlccCode: r.clearedMlccCode ?? null,
      upcMappingRemoved: mappingFlag.removed || clearedMap.removed,
    });
  } catch (e) {
    return res.status(500).json({ ok: false, error: e instanceof Error ? e.message : String(e) });
  }
}

export async function priceBookUpcHandler(req, res) {
  try {
    const rawUpc = String(req.params.upc ?? "").trim();
    if (!rawUpc) {
      return res.status(400).json({ ok: false, error: "upc_required" });
    }
    // Normalize to canonical 12-digit UPC-A (handles 14-digit GTIN-14 from
    // MLCC's price book, 12-digit UPC from scanner, anything in between).
    // Both sides of comparisons go through normalizeUpc — equality match works.
    const upc = normalizeUpc(rawUpc) ?? rawUpc;
    console.log("[price-book-upc] lookup", { rawUpc, normalized: upc });

    const mapping = await getUpcMapping(supabase, upc);
    if (mapping) {
      let { data: mlccItem, error: mapItemErr } = await supabase
        .from("mlcc_items")
        .select("*")
        .eq("code", mapping.mlccCode)
        // code is not unique alone (code+ada_number is) — pin to lowest ADA so
        // a multi-distributor SKU on the scan path can't 500 .maybeSingle().
        .order("ada_number", { ascending: true })
        .limit(1)
        .maybeSingle();
      /*
        Combo-swap (Tony's Casamigos bug, 2026-06-10): MLCC puts the SAME
        bottle UPC on both the regular SKU and gift-combo SKUs ("...W/50ML
        REPO W/"). If a non-user-confirmed mapping resolved to a combo,
        prefer the regular bottle that shares the UPC — a store owner
        scanning a fifth means the fifth, not the seasonal gift pack.
        User-confirmed mappings are never overridden.
      */
      if (
        mlccItem &&
        (isMlccComboName(mlccItem.name) || isMlccSpecialEditionName(mlccItem.name)) &&
        mapping.confidenceSource !== "user_confirmed"
      ) {
        const { data: upcSiblings } = await supabase
          .from("mlcc_items")
          .select("*")
          .eq("upc", upc)
          .limit(10);
        const regular = (upcSiblings ?? [])
          .filter((r) => !isMlccComboName(r.name) && !isMlccSpecialEditionName(r.name))
          .sort((a, b) => String(a.ada_number ?? "").localeCompare(String(b.ada_number ?? "")))[0];
        if (regular) {
          console.log(
            "[price-book-upc] combo-swap: mapping hit combo",
            mlccItem.code,
            "→ regular",
            regular.code,
          );
          mlccItem = regular;
        }
      }
      if (mapItemErr) {
        console.log("[price-book-upc] upc_mappings mlcc_items fetch error", mapItemErr.message);
      } else if (mlccItem) {
        void incrementUpcMappingScanCount(supabase, upc).catch(() => {});
        queueUpcLookupLog({
          upc,
          matched_mlcc_code: mlccItem.code ?? null,
          matched_product_name: mlccItem.name ?? null,
          source: "upc_mappings",
          raw_api_response: null,
        });
        queueUpcMatchAudit(supabase, {
          upc,
          upcBrand: null,
          upcProductName: mlccItem.name ?? null,
          upcProductNameRaw: mlccItem.name ?? null,
          matchedMlccCode: mlccItem.code != null ? String(mlccItem.code) : null,
          matchMode: "upc_mapping",
          confidenceScore: 100,
          confidenceWarning: null,
          scoringBreakdown: null,
          allCandidateScores: [],
          cached: true,
        });
        incrementScanCount(supabase, mlccItem.id);
        return res.json({
          ok: true,
          product: { ...mlccItem, imageUrl: null },
          source: "upc_mappings",
          confidenceSource: mapping.confidenceSource,
          scanCount: mapping.scanCount,
          message: "Authoritative mapping",
          matchMode: "confident",
          confidenceScore: 100,
          scoringBreakdown: null,
          allCandidateScores: [],
          imageUrl: null,
        });
      }
      void deleteUpcMapping(supabase, upc).catch(() => {});
    }

    /*
      Multiple mlcc_items rows can share one UPC (regular bottle + gift
      combos + multi-ADA rows). The old `.limit(1).maybeSingle()` picked an
      ARBITRARY row — Tony's fifth of Casamigos resolved to the "W/50ML
      REPO" gift combo by coin flip (2026-06-10). Deterministic preference:
      non-combo first, then lowest ADA.
    */
    const { data: localRows, error: localErr } = await supabase
      .from("mlcc_items")
      .select("*")
      .eq("upc", upc)
      .limit(10);

    if (localErr) {
      console.log("[price-book-upc] db error", localErr.message);
      return res.status(500).json({ ok: false, error: localErr.message });
    }
    const localRow = (localRows ?? [])
      .slice()
      .sort(
        (a, b) =>
          // Base product beats gift combos AND special editions (Lions/
          // McLaren class, 2026-06-10) — editions share the base UPC.
          Number(isMlccComboName(a.name)) - Number(isMlccComboName(b.name)) ||
          Number(isMlccSpecialEditionName(a.name)) - Number(isMlccSpecialEditionName(b.name)) ||
          String(a.ada_number ?? "").localeCompare(String(b.ada_number ?? "")),
      )[0] ?? null;
    if (localRow) {
      console.log("[price-book-upc] local match", localRow.id);
      queueUpcLookupLog({
        upc,
        matched_mlcc_code: localRow.code ?? null,
        matched_product_name: localRow.name ?? null,
        source: "local_cache",
        raw_api_response: null,
      });
      queueUpcMatchAudit(supabase, {
        upc,
        upcBrand: null,
        upcProductName: localRow.name ?? null,
        upcProductNameRaw: localRow.name ?? null,
        matchedMlccCode: localRow.code != null ? String(localRow.code) : null,
        matchMode: "local_cache",
        confidenceScore: 100,
        confidenceWarning: null,
        scoringBreakdown: null,
        allCandidateScores: [],
        cached: true,
      });
      incrementScanCount(supabase, localRow.id);
      return res.json({
        ok: true,
        product: { ...localRow, imageUrl: null },
        matchMode: "confident",
        confidenceScore: 100,
        scoringBreakdown: null,
        allCandidateScores: [],
        imageUrl: null,
      });
    }

    const upcDb = await lookupUpcFromUpcitemdb(upc);
    if (upcDb.ok && upcDb.product) {
      return respondWithScoredUpcMatch(res, {
        upc,
        upcItem: upcDb.product,
        rawApiResponse: upcDb.raw ?? null,
        source: "upcitemdb",
      });
    }

    const off = await lookupUpcFromOpenFoodFacts(upc);
    if (off.ok && off.product) {
      return respondWithScoredUpcMatch(res, {
        upc,
        upcItem: off.product,
        rawApiResponse: off.raw ?? null,
        source: "open_food_facts",
      });
    }

    queueUpcLookupLog({
      upc,
      matched_mlcc_code: null,
      matched_product_name: null,
      source: "not_found",
      raw_api_response: {
        upcitemdb: upcDb.ok ? null : { error: upcDb.error },
        open_food_facts: off.ok ? null : { error: off.error },
      },
    });
    return res.json({
      ok: false,
      error: "no_upc_data_found",
      hint: "manual_search_required",
      upc,
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.log("[price-book-upc] unexpected", msg);
    const u = String(req.params.upc ?? "").trim();
    return res.json({
      ok: false,
      error: "no_upc_data_found",
      hint: "manual_search_required",
      upc: u || undefined,
    });
  }
}

router.post("/upc/:upc/confirm", async (req, res) => {
  try {
    const actor = await requireUserOrServiceRole(req, res);
    if (!actor) return;
    const upc = String(req.params.upc ?? "").trim();
    const body = req.body && typeof req.body === "object" ? req.body : {};
    const mlccCode = typeof body.mlccCode === "string" ? body.mlccCode.trim() : "";
    if (!upc || !mlccCode) {
      return res.status(400).json({ ok: false, error: "upc_and_mlccCode_required" });
    }

    const { data: rows, error: selErr } = await supabase
      .from("mlcc_items")
      .select("*")
      .eq("code", mlccCode)
      .limit(1);

    if (selErr) {
      return res.status(500).json({ ok: false, error: selErr.message });
    }
    const row = rows?.[0];
    if (!row) {
      return res.json({ ok: false, error: "mlcc_code_not_found" });
    }

    let cached = false;
    if (ENABLE_PICKER_SELECTION_CACHE) {
      const { error: upErr } = await supabase.from("mlcc_items").update({ upc }).eq("id", row.id);
      if (upErr) {
        return res.status(500).json({ ok: false, error: upErr.message });
      }
      cached = true;
    } else {
      console.log(
        "[price-book-upc] confirm: picker selection applied for this scan only; UPC not persisted (ENABLE_PICKER_SELECTION_CACHE=false)",
        { upc, mlccCode },
      );
    }

    const { data: refreshed } = await supabase.from("mlcc_items").select("*").eq("id", row.id).maybeSingle();
    const product = refreshed ?? (ENABLE_PICKER_SELECTION_CACHE ? { ...row, upc } : row);

    const upcProductName =
      typeof body.upcProductName === "string" ? body.upcProductName.trim() || null : null;
    const upcBrand = typeof body.upcBrand === "string" ? body.upcBrand.trim() || null : null;
    const confirmedBy =
      typeof body.confirmedBy === "string" && body.confirmedBy.trim() ? body.confirmedBy.trim() : null;
    void upsertUpcMapping(supabase, {
      upc,
      mlccCode: String(product.code ?? mlccCode),
      confidenceSource: "user_confirmed",
      confirmedBy,
    });
    queueUpcLookupLog({
      upc,
      matched_mlcc_code: product.code ?? null,
      matched_product_name: product.name ?? null,
      source: "manual_confirm",
      raw_api_response:
        upcProductName || upcBrand ? { upcProductName, upcBrand, cached } : { cached },
    });

    return res.json({ ok: true, product, cached });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return res.status(500).json({ ok: false, error: msg });
  }
});

router.post("/upc/:upc/flag", priceBookUpcFlagHandler);
router.post("/upc/:upc/report-no-match", async (req, res) => {
  try {
    const actor = await requireUserOrServiceRole(req, res);
    if (!actor) return;
    const upc = String(req.params.upc ?? "").trim();
    if (!upc) {
      return res.status(400).json({ ok: false, error: "upc_required" });
    }
    const body = req.body && typeof req.body === "object" ? req.body : {};
    const upcProductName =
      typeof body.upcProductName === "string" && body.upcProductName.trim()
        ? body.upcProductName.trim()
        : null;
    const upcBrand = typeof body.upcBrand === "string" && body.upcBrand.trim() ? body.upcBrand.trim() : null;
    queueUpcMatchAudit(supabase, {
      upc,
      upcBrand,
      upcProductName,
      upcProductNameRaw: upcProductName,
      matchedMlccCode: null,
      matchMode: "user_rejected_all_candidates",
      confidenceScore: 0,
      confidenceWarning: "user_rejected_all_candidates",
      scoringBreakdown: null,
      allCandidateScores: [],
      cached: false,
    });
    return res.status(200).json({ ok: true });
  } catch (e) {
    if (typeof Sentry?.captureException === "function") {
      Sentry.captureException(e);
    }
    return res.status(500).json({ ok: false, error: e instanceof Error ? e.message : String(e) });
  }
});
router.get("/upc/:upc", priceBookUpcHandler);

router.get("/items/:code/family", async (req, res) => {
  try {
    const code = String(req.params.code ?? "").trim();
    if (!code) {
      return res.status(400).json({ ok: false, error: "code_required" });
    }

    // NOTE: mlcc_items.code is NOT unique — the same code can appear under
    // multiple ADAs (unique index is on (code, ada_number)). So a plain
    // .maybeSingle() ERRORS with "multiple rows returned" for any SKU sold by
    // 2+ distributors, which 500'd this endpoint and silently broke the product
    // card (Tony hit this on a double-shot Smirnoff at Colony, 2026-06-09).
    // Take the first matching row as the anchor — all rows share name/brand/
    // category, and filterToFamily() gathers the siblings anyway.
    const { data: anchorRows, error: aErr } = await supabase
      .from("mlcc_items")
      .select("*")
      .eq("code", code)
      .order("ada_number", { ascending: true })
      .limit(1);

    if (aErr) {
      return res.status(500).json({ ok: false, error: aErr.message });
    }
    const anchor =
      Array.isArray(anchorRows) && anchorRows.length > 0 ? anchorRows[0] : null;
    if (!anchor) {
      return res.json({ ok: false, error: "mlcc_code_not_found" });
    }

    /* ── family_key FAST PATH (2026-07-11, catalog-family-tree-plan wiring) ──
     *
     * The 7/1 engine (family-key.js) precomputed family_key / container /
     * pack_count / is_combo for every active row (13,828/13,828 backfilled,
     * audit-validated: 644 orphans healed, 0 over-merges) and the ingestor
     * now recomputes them on every price-book upsert. When the anchor has a
     * key, the family is ONE indexed equality query — no ILIKE pool, no
     * 500-row cap, no ADA split (root causes #3/#4/#5), and Tony's exact
     * plastic-pint-of-Jack bug is dead (PL is stripped into `container`
     * data instead of poisoning the name base).
     *
     * Category still filters alongside the key: ~20 keys legitimately span
     * 2 categories (plan follow-up #3).
     *
     * The legacy name-pool path below is UNCHANGED and still serves rows
     * whose family_key is NULL (a brand-new SKU ingested by a pre-2026-07-11
     * deploy) — fallback, not dead code, per the plan's safety rails.
     */
    const anchorFamilyKey = String(anchor.family_key ?? "").trim();
    if (anchorFamilyKey) {
      const fetchFamilyRows = async (familyKey) => {
        let fq = supabase
          .from("mlcc_items")
          .select("*")
          .eq("is_active", true)
          .eq("family_key", familyKey);
        const anchorCat = String(anchor.category ?? "").trim();
        if (anchorCat) {
          fq = fq.eq("category", anchorCat);
        }
        return fq
          .order("code", { ascending: true })
          .order("ada_number", { ascending: true })
          .limit(200);
      };

      let adoptedKey = anchorFamilyKey;
      const { data: keyRows, error: kErr } = await fetchFamilyRows(adoptedKey);
      if (kErr) {
        return res.status(500).json({ ok: false, error: kErr.message });
      }
      let members = familyMembersFromRows(anchor, keyRows ?? []);

      /*
        Truncated-combo fallback (plan follow-up #1): MLCC truncates long
        combo names, so the combo's key is a PREFIX of its real family key
        ("TITO'S HANDMADE VODK" → "TITO'S HANDMADE VODKA"). Only fires when
        the combo anchor is ALONE in its key, and only adopts a candidate
        when exactly ONE distinct non-combo key matches — an ambiguous
        guess risks a false merge, the one failure worse than a split.
        Any error here just keeps the singleton (honest beats guessed).
      */
      const anchorIsCombo = anchor.is_combo === true;
      const hasNonAnchorMembers = members.some(
        (m) => String(m.code) !== String(anchor.code),
      );
      if (
        anchorIsCombo &&
        !hasNonAnchorMembers &&
        anchorFamilyKey.length >= COMBO_PREFIX_FALLBACK_MIN_LEN
      ) {
        const { data: candRows, error: candErr } = await supabase
          .from("mlcc_items")
          .select("family_key, is_combo")
          .eq("is_active", true)
          .like("family_key", `${escapeLikePattern(anchorFamilyKey)}%`)
          .limit(200);
        if (!candErr) {
          const candidateKeys = (candRows ?? [])
            .filter((r) => r.is_combo !== true)
            .map((r) => r.family_key);
          const fallbackKey = pickComboPrefixFallbackKey(
            anchorFamilyKey,
            candidateKeys,
          );
          if (fallbackKey) {
            const { data: fbRows, error: fbErr } = await fetchFamilyRows(fallbackKey);
            if (!fbErr) {
              adoptedKey = fallbackKey;
              members = familyMembersFromRows(anchor, fbRows ?? []);
            }
          }
        }
      }

      const sizesOut = members.map((row) => {
        // Combo chip labeling parity with the legacy path (Casamigos twin-chip
        // bug, 2026-06-10) — is_combo is the engine's own verdict for this row.
        if (row.is_combo === true) {
          const baseLabel =
            String(row.bottle_size_label ?? "").trim() ||
            (row.bottle_size_ml ? `${row.bottle_size_ml} ML` : "PACK");
          return { ...row, bottle_size_label: `${baseLabel} · GIFT PACK` };
        }
        return row;
      });

      if (process.env.DEBUG_UPC_FILTER === "1") {
        console.log(
          "[price-book][DEBUG_UPC_FILTER][family]",
          JSON.stringify({
            requestedCode: code,
            grouping: "family_key",
            anchorKey: anchorFamilyKey,
            adoptedKey,
            familyCount: sizesOut.length,
            familyNames: sizesOut.map((r) => r.name),
          }),
        );
      }

      return res.json({
        ok: true,
        /*
          Combo anchors display the clean family name as the card title —
          the adopted key IS the normalized base (and after the prefix
          fallback it's the full untruncated one). The combo's own row is
          still in `sizes` with its real name/price.
        */
        baseName: anchorIsCombo ? adoptedKey : anchor.name,
        sizes: sizesOut,
        grouping: "family_key",
        familyKey: adoptedKey,
        mixedContainers: familyHasMixedContainers(members),
      });
    }

    let q = supabase.from("mlcc_items").select("*").eq("is_active", true);
    const cat = String(anchor.category ?? "").trim();
    if (cat) {
      q = q.eq("category", cat);
    }
    const adaName = String(anchor.ada_name ?? "").trim();
    if (adaName) {
      q = q.eq("ada_name", adaName);
    }
    const prefix = familyNameSearchPrefix(anchor);
    const safe = sanitizeIlikeForFamily(prefix);
    if (safe) {
      q = q.ilike("name", `%${safe}%`);
    }
    q = q.limit(500);
    const { data: pool, error: pErr } = await q;
    if (pErr) {
      return res.status(500).json({ ok: false, error: pErr.message });
    }

    let sizes = filterToFamily(anchor, pool ?? []);
    const seen = new Set((sizes ?? []).map((r) => r?.id).filter(Boolean));
    if (anchor.id && !seen.has(anchor.id)) {
      sizes = [anchor, ...sizes];
    }

    const dedup = [];
    const byId = new Set();
    for (const row of sizes) {
      if (!row?.id || byId.has(row.id)) continue;
      byId.add(row.id);
      /*
        Combo rows get a distinct size-tab label ("750 ML · GIFT PACK")
        so they can never render as an identical twin of the regular
        bottle's tab (Tony saw two indistinguishable "750 ML" chips on
        Casamigos, 2026-06-10).
      */
      if (isMlccComboName(row.name)) {
        const baseLabel =
          String(row.bottle_size_label ?? "").trim() ||
          (row.bottle_size_ml ? `${row.bottle_size_ml} ML` : "PACK");
        dedup.push({ ...row, bottle_size_label: `${baseLabel} · GIFT PACK` });
      } else {
        dedup.push(row);
      }
    }
    dedup.sort((a, b) => (Number(a.bottle_size_ml) || 0) - (Number(b.bottle_size_ml) || 0));

    const bf = String(anchor.brand_family ?? "").trim();
    const grouping = bf ? "brand_family_and_category" : "name_base_category_ada_name";

    if (process.env.DEBUG_UPC_FILTER === "1") {
      console.log(
        "[price-book][DEBUG_UPC_FILTER][family]",
        JSON.stringify({
          requestedCode: code,
          anchor: {
            code: anchor.code,
            name: anchor.name,
            brand_family: anchor.brand_family ?? null,
            category: anchor.category ?? null,
            ada_name: anchor.ada_name ?? null,
          },
          grouping,
          nameBase: normalizeMlccNameBaseForFamily(anchor.name),
          searchPrefix: prefix || null,
          poolCount: (pool ?? []).length,
          familyCount: dedup.length,
          familyNames: dedup.map((r) => r.name),
        }),
      );
    }

    return res.json({
      ok: true,
      /*
        Combo anchors (".. W/50ML REPO W/") display the clean base product
        name as the card title — the combo's own row is still in `sizes`
        with its real name/price. Tony's Casamigos bug, 2026-06-10.
      */
      baseName: isMlccComboName(anchor.name)
        ? normalizeMlccNameBaseForFamily(anchor.name) || anchor.name
        : anchor.name,
      sizes: dedup,
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return res.status(500).json({ ok: false, error: msg });
  }
});

/** Default list ordering for catalog search: popular scans first, then name. */
function orderMlccItemsByScanThenName(q) {
  return q.order("scan_count", { ascending: false }).order("name", { ascending: true });
}

/**
 * Levenshtein distance for short search tokens (name token vs query).
 * @param {string} a
 * @param {string} b
 * @returns {number}
 */
function levenshteinDistanceForSearch(a, b) {
  const m = a.length;
  const n = b.length;
  if (m === 0) return n;
  if (n === 0) return m;
  /** @type {number[]} */
  let prev = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) {
    const curr = [i];
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      curr[j] = Math.min(curr[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost);
    }
    prev = curr;
  }
  return prev[n];
}

/**
 * When ILIKE / trigram miss typos (e.g. "screwball" vs "SKREWBALL"), match any 4+ letter
 * name token within edit distance ≤ 2 of the longest query token.
 * @param {import("@supabase/supabase-js").SupabaseClient} supabase
 * @param {string} search
 * @param {string} adaNumber
 * @param {string | undefined} isNewItemQ
 * @param {number} from
 * @param {number} limit
 * @param {number} page
 * @returns {Promise<{ ok: true; items: object[]; total: number; page: number; fuzzy_match: true } | null>}
 */
async function tryLevenshteinNameTokenSearch(supabase, search, adaNumber, isNewItemQ, from, limit, page) {
  const normalized = normalizeSearchTerm(search);
  const words = normalized.split(/\s+/).filter((w) => w.length >= 4);
  if (!words.length) return null;
  const token = words.reduce((best, w) => (w.length > best.length ? w : best), words[0]);
  /** Sliding 3-char chunks so "screwball" → "rew" still hits "SKREWBALL" (prefix "scr" alone does not). */
  const prefixes = [];
  for (let i = 0; i <= token.length - 3; i++) {
    prefixes.push(token.slice(i, i + 3));
  }
  const uniqPrefixes = [...new Set(prefixes.map((p) => sanitizeIlikeValue(p)).filter((p) => p.length >= 3))].slice(
    0,
    12,
  );
  if (!uniqPrefixes.length) return null;
  const seen = new Set();
  const rows = [];
  for (const safe of uniqPrefixes) {
    let q = supabase.from("mlcc_items").select("*").ilike("name", `%${safe}%`).limit(200);
    q = applyMlccItemsFilters(q, adaNumber, isNewItemQ);
    const { data, error } = await q;
    if (error) {
      console.log("[price-book-items] fuzzy-token name search error", error.message);
      continue;
    }
    for (const row of data ?? []) {
      const id = String(row?.id ?? "");
      if (!id || seen.has(id)) continue;
      seen.add(id);
      rows.push(row);
      if (rows.length >= 500) break;
    }
    if (rows.length >= 500) break;
  }
  const hits = [];
  for (const row of rows) {
    const nn = normalizeSearchTerm(String(row.name ?? ""));
    const parts = nn.split(/\s+/).filter((p) => p.length >= 4);
    const compact = nn.replace(/[^a-z0-9]+/g, "");
    let ok = false;
    for (const part of parts) {
      if (levenshteinDistanceForSearch(token, part) <= 2) {
        ok = true;
        break;
      }
    }
    if (!ok && compact.length >= token.length) {
      for (let i = 0; i <= compact.length - token.length; i++) {
        const slice = compact.slice(i, i + token.length);
        if (levenshteinDistanceForSearch(token, slice) <= 2) {
          ok = true;
          break;
        }
      }
    }
    if (ok) hits.push(row);
  }
  if (!hits.length) return null;
  const sortedHits = sortByRelevance(hits, new Set(extractSearchTokens(search)));
  const total = sortedHits.length;
  const items = sortedHits.slice(from, from + limit);
  return { ok: true, items, total, page, fuzzy_match: true };
}

/**
 * GET /items/grouped?search=…&limit=… — grouped search (plan §C, 2026-07-11).
 *
 * Same matching pipeline as /items (applyItemsOrSearchToQuery = brand
 * aliases + suffix aliases + auto-prefix, then relevance re-rank), but the
 * OUTPUT collapses to family cards: one row per product line with size
 * count, price range, mixed-container flag, and a representative row for
 * the thumbnail + tap-through (client opens the ProductCard tree at the
 * representative's code — the tree endpoint owns membership from there).
 *
 * ADDITIVE route: /items itself is byte-untouched (the AI resolver and
 * other consumers keep their exact contract), and the client keeps flat
 * search one flag-flip away (plan §safety). No pagination by design —
 * top N family cards answer a human query; "page 2 of families" is not a
 * real need (YAGNI, scope hardened).
 *
 * Typo fallback lives CLIENT-side: zero groups → the scanner re-runs the
 * flat /items search, which has the fuzzy RPC — so misspellings keep
 * working exactly as before, just ungrouped.
 */
router.get("/items/grouped", async (req, res) => {
  try {
    const search = typeof req.query.search === "string" ? req.query.search.trim() : "";
    if (!search) {
      return res.status(400).json({ ok: false, error: "search_required" });
    }
    let limitGroups = Number.parseInt(String(req.query.limit || "30"), 10);
    if (!Number.isFinite(limitGroups) || limitGroups < 1) limitGroups = 30;
    limitGroups = Math.min(limitGroups, 60);
    const adaNumber = typeof req.query.adaNumber === "string" ? req.query.adaNumber.trim() : "";

    /*
      Browse filters (2026-07-11 pt.2 — Tony: grouped search "should be
      everywhere"): the Catalog tab passes its active filters so its
      grouped results respect them. Filters gate WHICH rows match the
      search; a numeric-code hit's family tree itself stays unfiltered —
      the tree is the tree. Size filter deliberately absent: filtering to
      one size means the user wants specific bottles, so the client stays
      flat in that case.
    */
    const category = typeof req.query.category === "string" ? req.query.category.trim() : "";
    const minPrice = Number.parseFloat(String(req.query.minPrice ?? ""));
    const maxPrice = Number.parseFloat(String(req.query.maxPrice ?? ""));
    const minProof = Number.parseFloat(String(req.query.minProof ?? ""));
    const maxProof = Number.parseFloat(String(req.query.maxProof ?? ""));
    /*
      Advanced filters in typed search (2026-07-17 — closing the fire-order
      gap: browse modes applied these four but grouped SEARCH didn't). These
      three are pure item-column filters, so they mirror browse_families v4's
      WHERE clause exactly. "Ordered before" is NOT here yet: it needs the
      store identity (p_ordered_store), and /price-book mounts WITHOUT the
      resolve-store middleware — wiring that securely is a separate change.
    */
    const newOnly = req.query.new_only === "1" || req.query.new_only === "true";
    const container =
      req.query.container === "glass" || req.query.container === "plastic"
        ? req.query.container
        : null;
    const packs =
      req.query.packs === "singles" || req.query.packs === "packs"
        ? req.query.packs
        : null;
    /*
      ONE SEARCH BRAIN (2026-08-15, Tony's renovation trigger: "ole smoky
      + 50ml starts trippen"). The size filter used to be deliberately
      absent here — the client dropped to the FLAT browse path when a
      size was picked, which swapped the abbreviation-aware ranked
      search for a dumb substring match. Same typed words, dumber brain,
      just because a size was on. Now grouped search takes the size like
      any other filter: cards simply contain the matching size only.
    */
    const bottleSizeMl = Number.parseInt(String(req.query.bottle_size_ml ?? ""), 10);
    const applyGroupedBrowseFilters = (q) => {
      let out = q;
      if (category) out = out.eq("category", category);
      if (Number.isFinite(bottleSizeMl)) out = out.eq("bottle_size_ml", bottleSizeMl);
      if (Number.isFinite(minPrice)) out = out.gte("licensee_price", minPrice);
      if (Number.isFinite(maxPrice)) out = out.lte("licensee_price", maxPrice);
      if (Number.isFinite(minProof)) out = out.gte("proof", minProof);
      if (Number.isFinite(maxProof)) out = out.lte("proof", maxProof);
      // is_new_item IS TRUE
      if (newOnly) out = out.eq("is_new_item", true);
      // container: null/empty counts as glass (v4: coalesce(nullif(btrim..),'glass'))
      if (container === "glass") out = out.or("container.is.null,container.eq.glass");
      else if (container === "plastic") out = out.eq("container", "plastic");
      // packs: singles = pack_count<2 (null→1) AND is_combo NOT TRUE; packs =
      // pack_count>=2 OR combo. `.not(is_combo,is,true)` = "is_combo IS NOT
      // TRUE" (false or null) in one filter — avoids a second OR group.
      if (packs === "singles") {
        out = out.or("pack_count.is.null,pack_count.lt.2").not("is_combo", "is", true);
      } else if (packs === "packs") {
        out = out.or("pack_count.gte.2,is_combo.is.true");
      }
      return out;
    };

    // Numeric query = exact code lookup, same convention as /items. The
    // single hit's WHOLE family becomes the one card (fetch by its key so
    // sizeCount/price-range reflect the real family, not just the hit).
    if (/^\d+$/.test(search)) {
      let qExact = supabase.from("mlcc_items").select("*").eq("code", search);
      qExact = applyMlccItemsFilters(qExact, adaNumber, undefined);
      qExact = applyGroupedBrowseFilters(qExact);
      const { data: hits, error: exErr } = await orderMlccItemsByScanThenName(qExact).limit(5);
      if (exErr) {
        return res.status(500).json({ ok: false, error: exErr.message });
      }
      const hit = hits?.[0];
      if (!hit) return res.json({ ok: true, groups: [] });
      const hitKey = String(hit.family_key ?? "").trim();
      let familyRows = [hit];
      if (hitKey) {
        let fq = supabase
          .from("mlcc_items")
          .select("*")
          .eq("is_active", true)
          .eq("family_key", hitKey);
        const hitCat = String(hit.category ?? "").trim();
        if (hitCat) fq = fq.eq("category", hitCat);
        const { data: famRows, error: famErr } = await fq.limit(200);
        // On error keep the single hit — a thinner card beats a 500.
        if (!famErr && Array.isArray(famRows) && famRows.length > 0) {
          familyRows = [hit, ...famRows.filter((r) => r.id !== hit.id)];
        }
      }
      return res.json({ ok: true, groups: groupRowsIntoFamilies(familyRows).slice(0, limitGroups) });
    }

    // Text query: precise token match, relevance-ranked, pooled wide so
    // sibling sizes land in the same response (a family's sizes share the
    // base name, so they match the same tokens). 300 caps the payload;
    // a clipped pool only under-counts sizeCount on gigantic result sets —
    // the tap-through tree is always complete regardless.
    let q = supabase.from("mlcc_items").select("*");
    q = applyItemsOrSearchToQuery(q, search);
    q = applyMlccItemsFilters(q, adaNumber, undefined);
    q = applyGroupedBrowseFilters(q);
    const { data: pool, error: pErr } = await orderMlccItemsByScanThenName(q).limit(300);
    if (pErr) {
      return res.status(500).json({ ok: false, error: pErr.message });
    }
    const ranked = sortByRelevance(pool ?? [], new Set(extractSearchTokens(search)));
    return res.json({
      ok: true,
      groups: groupRowsIntoFamilies(ranked).slice(0, limitGroups),
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return res.status(500).json({ ok: false, error: msg });
  }
});

router.get("/items", async (req, res) => {
  try {
    let page = Number.parseInt(String(req.query.page || "1"), 10);
    let limit = Number.parseInt(String(req.query.limit || "50"), 10);
    if (!Number.isFinite(page) || page < 1) page = 1;
    if (!Number.isFinite(limit) || limit < 1) limit = 50;
    limit = Math.min(limit, 200);

    const search = typeof req.query.search === "string" ? req.query.search.trim() : "";
    const adaNumber = typeof req.query.adaNumber === "string" ? req.query.adaNumber.trim() : "";
    const isNewItemQ = req.query.isNewItem;

    const from = (page - 1) * limit;
    const to = from + limit - 1;

    if (search && /^\d+$/.test(search)) {
      let qExact = supabase.from("mlcc_items").select("*", { count: "exact" }).eq("code", search);
      qExact = applyMlccItemsFilters(qExact, adaNumber, isNewItemQ);
      const exactRes = await orderMlccItemsByScanThenName(qExact).range(from, to);
      if (exactRes.error) {
        return res.status(500).json({ ok: false, error: exactRes.error.message });
      }
      if (exactRes.data?.length) {
        return res.json({
          ok: true,
          items: exactRes.data,
          total: exactRes.count ?? 0,
          page,
        });
      }

      let qName = supabase.from("mlcc_items").select("*", { count: "exact" }).ilike("name", `%${search}%`);
      qName = applyMlccItemsFilters(qName, adaNumber, isNewItemQ);
      const nameRes = await orderMlccItemsByScanThenName(qName).range(from, to);
      if (nameRes.error) {
        return res.status(500).json({ ok: false, error: nameRes.error.message });
      }
      return res.json({
        ok: true,
        items: nameRes.data || [],
        total: nameRes.count ?? 0,
        page,
      });
    }

    if (search) {
      // NOTE: previously there were TWO search paths — `multiTermBrandSearch`
      // for queries containing a known brand alias key, and the
      // `applyItemsOrSearchToQuery` path for everything else. The brand-key
      // path didn't apply truncation aliases or auto-prefix to the SUFFIX
      // words, which caused "stolichnaya vanilla" to require literal
      // "vanilla" in MLCC name (which is stored as "VANIL") → 0 matches →
      // fuzzy fallback returned random vanillas. Now there's ONE unified
      // path: applyTokenAndSearchToQuery (alias `applyItemsOrSearchToQuery`)
      // handles brand aliases AND suffix-word aliases AND auto-prefix
      // truncation. It's a superset of the old brand-key path.

      let qOrHead = supabase.from("mlcc_items").select("*", { count: "exact", head: true });
      qOrHead = applyItemsOrSearchToQuery(qOrHead, search);
      qOrHead = applyMlccItemsFilters(qOrHead, adaNumber, isNewItemQ);
      const { count: orCount, error: orHeadErr } = await qOrHead;
      if (orHeadErr) {
        return res.status(500).json({ ok: false, error: orHeadErr.message });
      }

      // If the AND-of-tokens query returns ANY rows, return those — the user
      // typed a query that narrowed the catalog to specific matches and that's
      // the most precise answer we have. Falling through to fuzzy RPC only
      // helps when there were ZERO precise matches (probable typo). The
      // previous `>= 3` threshold silently dropped niche but valid hits like
      // "valentine white blossom" (1 exact MLCC row, fell to fuzzy, lost).
      if (orCount != null && orCount >= 1) {
        const queryTokenSet = new Set(extractSearchTokens(search));
        /*
          Brand-family searches (e.g. "jack daniels") commonly match a small
          set of SKUs (the whole product line). Pre-launch, scan_count is 0
          for all of them, so the DB-side `orderMlccItemsByScanThenName`
          falls through to alphabetical — which puts "JACK DANIELS APPLE"
          ahead of "JACK DANIELS OLD #7" (Tony, 2026-06-13). When the match
          set is small enough to fetch in one page, re-rank it client-side
          with sortByRelevance so the flagship bottle surfaces first. Large
          result sets (single-token searches across the whole catalog) keep
          the cheap DB-ordered + paginated path.
        */
        const RELEVANCE_SORT_CAP = 200;
        if (orCount <= RELEVANCE_SORT_CAP) {
          let qOrAll = supabase.from("mlcc_items").select("*");
          qOrAll = applyItemsOrSearchToQuery(qOrAll, search);
          qOrAll = applyMlccItemsFilters(qOrAll, adaNumber, isNewItemQ);
          const { data: allItems, error: allErr } = await qOrAll.range(0, RELEVANCE_SORT_CAP - 1);
          if (allErr) {
            return res.status(500).json({ ok: false, error: allErr.message });
          }
          const sorted = sortByRelevance(allItems, queryTokenSet);
          return res.json({
            ok: true,
            items: sorted.slice(from, from + limit),
            total: orCount,
            page,
          });
        }
        let qOr = supabase.from("mlcc_items").select("*", { count: "exact" });
        qOr = applyItemsOrSearchToQuery(qOr, search);
        qOr = applyMlccItemsFilters(qOr, adaNumber, isNewItemQ);
        const { data: orItems, error: orErr, count } = await orderMlccItemsByScanThenName(qOr).range(from, to);
        if (orErr) {
          return res.status(500).json({ ok: false, error: orErr.message });
        }
        return res.json({
          ok: true,
          items: orItems || [],
          total: count ?? 0,
          page,
        });
      }

      const { data: fuzzyRowsNoBrand, error: fuzzyErrNoBrand } = await supabase.rpc(
        "search_mlcc_items_fuzzy",
        {
          search_query: search,
          match_threshold: 0.15,
          result_limit: limit * 3,
        },
      );
      if (fuzzyErrNoBrand) {
        return res.status(500).json({ ok: false, error: fuzzyErrNoBrand.message });
      }
      let filteredNoBrand = sortByRelevance(
        filterMlccRowsClientSide(fuzzyRowsNoBrand, adaNumber, isNewItemQ),
        new Set(extractSearchTokens(search)),
      );
      let totalNb = filteredNoBrand.length;
      let itemsNb = filteredNoBrand.slice(from, from + limit);
      if (totalNb === 0) {
        const fb = await tryLevenshteinNameTokenSearch(
          supabase,
          search,
          adaNumber,
          isNewItemQ,
          from,
          limit,
          page,
        );
        if (fb) return res.json(fb);
      }
      return res.json({
        ok: true,
        items: itemsNb,
        total: totalNb,
        page,
      });
    }

    let q = supabase.from("mlcc_items").select("*", { count: "exact" });

    q = applyMlccItemsFilters(q, adaNumber, isNewItemQ);

    const { data: items, error, count } = await orderMlccItemsByScanThenName(q).range(from, to);

    if (error) {
      return res.status(500).json({ ok: false, error: error.message });
    }

    res.json({
      ok: true,
      items: items || [],
      total: count ?? 0,
      page,
    });
  } catch (e) {
    res.status(500).json({
      ok: false,
      error: e instanceof Error ? e.message : String(e),
    });
  }
});


/**
 * GET /price-book/items/:code/related — "More from this brand"
 * (2026-07-26, TONY-WANTS: design locked via Q&A).
 *
 * mode "brand":   other families of the same brand_family, ranked by the
 *                 all-LK-stores order aggregate (ordered_count — Tony's
 *                 hybrid), scans as tiebreak.
 * mode "similar": thin brands (<2 sibling families) fall back to same
 *                 category + similar price ("if you're buying this,
 *                 these move too").
 *
 * Read-only, ≤400-row pulls, ordered server-side so the cap keeps the
 * best sellers. Same non-unique-code anchor rule as /items/:code/family.
 */
router.get("/items/:code/related", async (req, res) => {
  try {
    const code = String(req.params.code ?? "").trim();
    if (!code) {
      return res.status(400).json({ ok: false, error: "code_required" });
    }
    const { data: anchorRows, error: aErr } = await supabase
      .from("mlcc_items")
      .select("*")
      .eq("code", code)
      .order("ada_number", { ascending: true })
      .limit(1);
    if (aErr) return res.status(500).json({ ok: false, error: aErr.message });
    const anchor =
      Array.isArray(anchorRows) && anchorRows.length > 0 ? anchorRows[0] : null;
    if (!anchor) return res.json({ ok: false, error: "mlcc_code_not_found" });

    const anchorKey = String(anchor.family_key ?? "").trim() || null;
    const brand = String(anchor.brand_family ?? "").trim();
    const SELECT_COLS =
      "id,code,name,brand_family,category,ada_number,ada_name,proof," +
      "bottle_size_label,bottle_size_ml,case_size,licensee_price," +
      "min_shelf_price,base_price,container,pack_count,is_new_item," +
      "image_url,family_key,is_combo,is_active,ordered_count,scan_count";

    let mode = "brand";
    let brandLabel = brand || null;
    let families = [];

    if (brand) {
      const { data: rows, error } = await supabase
        .from("mlcc_items")
        .select(SELECT_COLS)
        .eq("is_active", true)
        .eq("brand_family", brand)
        .order("ordered_count", { ascending: false, nullsFirst: false })
        .limit(400);
      if (error) return res.status(500).json({ ok: false, error: error.message });
      families = rankFamilies(
        groupIntoFamilies(rows, { excludeFamilyKey: anchorKey }),
      );
    }

    /* Brand ladder (2026-07-26, the Jim Beam finding): brand_family is
       NULL-sparse in the catalog (the ingestor preserves it; nothing
       populates it), so big brands fell straight to "More like this".
       MLCC names lead with the brand, so recover the lineup by
       leading-name-prefix: two-token ("JIM BEAM") first, one-token
       ("SKYY") second. First rung yielding a real lineup (2+ families)
       wins and names the section. */
    if (families.length < 2) {
      for (const prefix of brandPrefixesFor(anchor.name)) {
        const { data: rows, error } = await supabase
          .from("mlcc_items")
          .select(SELECT_COLS)
          .eq("is_active", true)
          .ilike("name", `${escapeIlike(prefix)}%`)
          .order("ordered_count", { ascending: false, nullsFirst: false })
          .limit(400);
        if (error) return res.status(500).json({ ok: false, error: error.message });
        const found = rankFamilies(
          groupIntoFamilies(rows, { excludeFamilyKey: anchorKey }),
        );
        if (found.length >= 2) {
          families = found;
          brandLabel = prefix;
          mode = "brand";
          break;
        }
      }
    }

    if (families.length < 2) {
      mode = "similar";
      const category = String(anchor.category ?? "").trim();
      let q = supabase
        .from("mlcc_items")
        .select(SELECT_COLS)
        .eq("is_active", true);
      if (category) q = q.eq("category", category);
      const band = priceBandFor(anchor.licensee_price);
      if (band) q = q.gte("licensee_price", band.min).lte("licensee_price", band.max);
      const { data: rows, error } = await q
        .order("ordered_count", { ascending: false, nullsFirst: false })
        .order("scan_count", { ascending: false, nullsFirst: false })
        .limit(400);
      if (error) return res.status(500).json({ ok: false, error: error.message });
      // Different brands only — the thin brand already showed what it has.
      const pool = (rows ?? []).filter(
        (r) => !brand || String(r.brand_family ?? "").trim() !== brand,
      );
      families = rankFamilies(
        groupIntoFamilies(pool, { excludeFamilyKey: anchorKey }),
      );
    }

    return res.json({
      ok: true,
      mode,
      brand: brandLabel,
      items: families.map((f) => ({
        product: f.representative,
        sizes_count: f.sizes_count,
        from_price: f.from_price,
      })),
    });
  } catch (e) {
    return res.status(500).json({ ok: false, error: e?.message ?? String(e) });
  }
});

// Exported for unit testing the search-ranking heuristic (2026-06-13,
// "jack daniels" flagship-vs-variant fix) without spinning up Supabase.
export { sortByRelevance, computeVariantPenalty, extractSearchTokens, VARIANT_KEYWORDS };

export default router;
